//增加商品数量
function addNumber(stock,enterNum){							
	var stocka=parseFloat(stock);//数量
	/*注释:在js中最好使用js代码，不然会复杂*/
	var numA=$(event.srcElement).prev().val();//获取页面数量
	
	var price=parseFloat(enterNum);
	var count=parseFloat(numA)+1;
	var add=price*count;
	$(event.srcElement).parent().parent().next().text(add);//修改小计
	if (count>stocka) {
		alert("商品数量不足");
		return;
	}else{
		$(event.srcElement).prev().val(count);
	}
	cat(add);
}

//减少商品的数量
function jianNumber(stock,enterNum){
	var numB=$(event.srcElement).next().val()-1;
	var count=parseFloat(numB);
	
	var price=parseFloat(enterNum);
	var add=price*count;
	$(event.srcElement).parent().parent().next().text(add);
	if (count==0) {
		count==1;
		$(event.srcElement).parent().parent().next().text(enterNum);
		return;
	}
	$(event.srcElement).next().val(count);
	cat(add);
}
//计算总价
function cat(add){
	var sum=0;
	var $data=$(".price2");
	$data.each(function(){
		sum+=parseInt($(this).html());
	});
	$(".fr .phone").html(sum);
}