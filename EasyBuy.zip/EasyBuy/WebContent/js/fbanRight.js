
//右侧轮播图
jQuery(document).ready(function() {
	var t = false;
	var str = '';
	var speed = 500;
	var w = 234;
	var n =3;
	var numWidth = n * 18;
	var _left = (w - (numWidth + 26)) / 2;
	var c = 0;
	jq('#actor2').width(w * n);
	jq('#actor2 li').each(function(i) {
		str += '<span></span>'
	});
	jq('#numInner').width(numWidth).html(str);
	jq('#imgPlay2 .mc').width(numWidth);
	jq('#imgPlay2 .num').css('left', _left);
	jq('#numInner').css('left', _left + 13);
	jq('#numInner span:first').addClass('on');
	function cur(ele, currentClass) {
		ele = jq(ele) ? jq(ele) : ele;
		ele.addClass(currentClass).siblings().removeClass(currentClass)
	}
	jq('.fre_ban2 #imgPlay2 .nextf2').click(function() {
		slide(1)
	});
	jq('.fre_ban2 #imgPlay2 .prevf2').click(function() {
		slide( - 1)
	});
	function slide(j) {
		if (jq('#actor2').is(':animated') == false) {
			c += j;
			if (c != -1 && c != n) {
				jq('#actor2').animate({
					'marginLeft': -c * w + 'px'
				},
				speed)
			} else if (c == -1) {
				c = n - 1;
				jq("#actor2").css({
					"marginLeft": -(w * (c - 1)) + "px"
				});
				jq("#actor2").animate({
					"marginLeft": -(w * c) + "px"
				},
				speed)
			} else if (c == n) {
				c = 0;
				jq("#actor2").css({
					"marginLeft": -w + "px"
				});
				jq("#actor2").animate({
					"marginLeft": 0 + "px"
				},
				speed)
			}
			cur(jq('#numInner span').eq(c), 'on')
		}
	}
	jq('#numInner span').click(function() {
		c = jq(this).index();
		fade(c);
		cur(jq('#numInner span').eq(c), 'on')
	});
	function fade(i) {
		if (jq('#actor2').css('marginLeft') != -i * w + 'px') {
			jq('#actor2').css('marginLeft', -i * w + 'px');
			jq('#actor2').fadeOut(0,
			function() {
				jq('#actor2').fadeIn(500)
			})
		}
	}
	function start() {
		t = setInterval(function() {
			slide(1)
		},
		5000)
	}
	function stopt() {
		if (t) clearInterval(t)
	}
	jq("#imgPlay2").hover(function() {
		stopt()
	},
	function() {
		start()
	});
	start()
});