package cn.easybuy.util;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Map;

public class EmptyUtils {
	private EmptyUtils() {
        throw new UnsupportedOperationException("u can't instantiate me...");
    }

    /**
     * 判断对象是否为空
     *
     * @param obj 对象
     * @return {@code true}: 为空<br>{@code false}: 不为空
     */
    public static boolean isEmpty(Object obj) {
        if (obj == null) {
            return true;
        }
        if(obj instanceof CharSequence){
        	return ((CharSequence)obj).length() == 0;
        }
        if (obj instanceof Collection && ((Collection) obj).isEmpty()) {
            return true;
        }
        if (obj instanceof Map && ((Map) obj).isEmpty()) {
            return true;
        }
        if (obj instanceof String && obj.toString().length() == 0) {
            return true;
        }
       if(obj instanceof Object[]){
    	   Object[] object = (Object[])obj;
    	   if(object.length == 0){
    		   return true;
    	   }
    	   boolean empty = true;
    	   for(int i=0;i<object.length;i++){
    		   if(!isEmpty(object[i])){
    			   empty = false;
    			   break;
    		   }
    	   }
    	   return empty;
       }
        return false;
    }

    /**
     * 判断对象是否非空
     *
     * @param obj 对象
     * @return {@code true}: 非空<br>{@code false}: 空
     */
    public static boolean isNotEmpty(Object obj) {
        return !isEmpty(obj);
    }
    private boolean validPropertyEmpty(Object ...args){
    	for(int i = 0;i<args.length;i++){
    		if(EmptyUtils.isEmpty(args[i])){
    			return true;
    		}
    	}
    	return false;
    }
}
