package cn.easybuy.util;

import java.util.List;

import cn.easybuy.pojo.Category;
import cn.easybuy.pojo.News;
import cn.easybuy.pojo.Order;
import cn.easybuy.pojo.Product;
import cn.easybuy.pojo.User;

//page类
public class Page {	

	//当前页码
	private int currPageNo=1;		//当前页码

	//每页显示的条目
	private int pageSize=5;			//页面大小，每页显示记录数
	
	//总的页数
	private int totalCount;			//记录总数
	
	//总记录数
	private int totalPageCount;		//总页数
	
	//当前页面数据集合
	List<User>userList;				//用户集合
	List<Order>orderList;			//订单集合
	List<Product>productList;		//商品集合
	List<News>newList;				//资讯集合
	List<Category>categoryList;		//分类集合
	
	
	
	

	public int getCurrPageNo() {
		return currPageNo;
	}

	public void setCurrPageNo(int currPageNo) {
		this.currPageNo = currPageNo;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize =pageSize==0?5:pageSize;
	}

	public int getTotalCount() {
		return totalCount;
	}

	//总数据数和总页数的计算
	public void setTotalCount(int totalCount) {
		if(totalCount>0){
			this.totalCount=totalCount;
			//计算总页数
			totalPageCount=(totalCount%pageSize==0)?(totalCount/pageSize):(totalCount/pageSize+1);
		}else {
			totalCount=0;
			totalPageCount=0;
		}
	}

	public int getTotalPageCount() {
		return totalPageCount;
	}
	
	public void setTotalPageCount(int totalPageCount) {
		this.totalPageCount = totalPageCount;
	}

	public List<User> getUserList() {
		return userList;
	}

	public void setUserList(List<User> userList) {
		this.userList = userList;
	}

	public List<Order> getOrderList() {
		return orderList;
	}

	public void setOrderList(List<Order> orderList) {
		this.orderList = orderList;
	}

	public List<Product> getProductList() {
		return productList;
	}

	public void setProductList(List<Product> productList) {
		this.productList = productList;
	}

	public List<News> getNewList() {
		return newList;
	}

	public void setNewList(List<News> newList) {
		this.newList = newList;
	}

	public List<Category> getCategoryList() {
		return categoryList;
	}

	public void setCategoryList(List<Category> categoryList) {
		this.categoryList = categoryList;
	}
	
	
	
}
