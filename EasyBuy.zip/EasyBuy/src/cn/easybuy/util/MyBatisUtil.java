package cn.easybuy.util;

import java.io.IOException;
import java.io.InputStream;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

/**
 * mybatis工具类 单例类
 * @author fitting
 *
 */
public class MyBatisUtil {
	//私有化sqlsessionFactory
	private static SqlSessionFactory sqlSessionFactory=null;
	
	//静态加载
	static{
		createSqlSessionFactory();
	}
	
	//创建工厂
	private static void createSqlSessionFactory(){
		if(sqlSessionFactory==null){
			String resource="mybatis-config.xml";
			InputStream is;
			try {
				is = Resources.getResourceAsStream(resource);
				sqlSessionFactory=new SqlSessionFactoryBuilder().build(is);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}
	
	
	//提供对外接口  获得sqlsessionFactory
	public static SqlSession getSqlSession(){
		return sqlSessionFactory.openSession(true);
	}
	
	
	/**
	 * 关闭资源
	 */
	public static void closeSqlSession(SqlSession session){
		if(session!=null){
			session.close();
		}
	}
	
	
}
