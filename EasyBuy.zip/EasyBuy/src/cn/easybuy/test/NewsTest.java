package cn.easybuy.test;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;
import org.junit.Test;

import cn.easybuy.dao.news.NewsMapper;
import cn.easybuy.dao.user.UserMapper;
import cn.easybuy.pojo.News;
import cn.easybuy.service.news.NewsServiceImpl;
import cn.easybuy.util.MyBatisUtil;
import cn.easybuy.util.Page;

public class NewsTest {
	
	private Logger log=Logger.getLogger(NewsTest.class);
	
	//查询所有资讯信息总量
	@Test
	public void testSelectNewsAll(){
		SqlSession session=null;
		int num=0;
		List<News>list=null;
		try {
			session=MyBatisUtil.getSqlSession();
			list=session.getMapper(NewsMapper.class).selectNewsAll();
			log.debug("资讯数据为:"+list.size());
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
	}
	
	
	
	
	
	//查询所有资讯信息总量
	@Test
	public void testSelectNewsAll2(){
		SqlSession session=null;
		List<News>list=null;
		list=new NewsServiceImpl().selectAll();
		log.debug("资讯数据为:"+list.size());
	}
	
	
	
	
	//查询所有资讯信息总量
	@Test
	public void testSelectTotalNewsCount(){
		SqlSession session=null;
		int num=0;
		try {
			session=MyBatisUtil.getSqlSession();
			num=session.getMapper(NewsMapper.class).selectTotalNewsCount();
			log.debug("资讯数据为:"+num);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
	}
	
	
	
	
	
	
	
	//查询所有资讯信息总量
	@Test
	public void testSelectTotalNewsCount2(){
		int num=0;
		num=new NewsServiceImpl().selectTotalNewsCount();
		log.debug("资讯数据为:"+num);
	}
	
	
	
	
	
	//查询所有资讯信息
	@Test
	public void testSelectNews(){
		SqlSession session=null;
		List<News>list=null;
		try {
			session=MyBatisUtil.getSqlSession();
			list=session.getMapper(NewsMapper.class).selectNews(15, 15);
			log.debug("资讯数据为:"+list.size());
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
	}
	
	
	
	
	
	//查询所有资讯信息
	@Test
	public void testSelectNews2(){
		Page page=new NewsServiceImpl().selectNews(3, 15);
		List<News>list=page.getNewList();
		log.debug("当前页码为："+page.getCurrPageNo());
		log.debug("总页码数为："+page.getTotalPageCount());
		log.debug("页数据为："+page.getPageSize());
		for (News news : list) {
			log.debug("资讯标题为:"+news.getTitle());
		}
		log.debug("资讯数据为:"+list.size());
	}
	
	
	
	
	
	
	
	//根据id查询资讯信息
	@Test
	public void testSelectNewById(){
		News news=new News();
		SqlSession session=null;
		try {
			session=MyBatisUtil.getSqlSession();
			news=session.getMapper(NewsMapper.class).selectNewById(649);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		
		log.debug("资讯标题为：-------------------->"+news.getTitle());
		log.debug("资讯内容为：-------------------->"+news.getContent());
	}
	
	
	
	
	
	
	//根据id查询资讯信息
	@Test
	public void testSelectNewById2(){
		News news=new News();
		news=new NewsServiceImpl().selectNewById(649);
		log.debug("资讯标题为：-------------------->"+news.getTitle());
		log.debug("资讯内容为：-------------------->"+news.getContent());
	}
	
	
	
	
	
	//增加资讯信息
	@Test
	public void testAddNews(){
		News news=new News();
		news.setTitle("你好");
		news.setContent("哈哈哈是的合法挥洒哈地方");
		SqlSession session=null;
		int count=0;
		try {
			session=MyBatisUtil.getSqlSession();
			count=session.getMapper(NewsMapper.class).addNews(news);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		
		log.debug("添加成功：-------------------->"+count);
	}
	
	
	
	
	
	
	
	//增加资讯信息
	@Test
	public void testAddNews2(){
		News news=new News();
		news.setTitle("你好");
		news.setContent("哈哈哈是的合法挥洒哈地方");
		int count=0;
		count=new NewsServiceImpl().addNews(news);
		log.debug("添加成功：-------------------->"+count);
	}
	
	
	
	
	
	
	//修改资讯信息
	@Test
	public void testUpdateNews(){
		News news=new News();
		news.setId(708);
		news.setTitle("你好");
		news.setContent("哈哈哈是的合法挥洒哈地方");
		SqlSession session=null;
		int count=0;
		try {
			session=MyBatisUtil.getSqlSession();
			count=session.getMapper(NewsMapper.class).updateNews(news);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		
		log.debug("修改成功：-------------------->"+count);
	}
	
	
	
	
		
	
	
	//修改资讯信息
	@Test
	public void testUpdateNews2(){
		News news=new News();
		news.setId(708);
		news.setTitle("你好");
		news.setContent("哈哈哈是的合法挥洒哈地方");
		int count=0;
		count=new NewsServiceImpl().updateNews(news);
		log.debug("修改成功：-------------------->"+count);
	}
	
	
	
	
	
	
	
	//删除资讯信息
	@Test
	public void testDeleteNews(){
		News news=new News();
		SqlSession session=null;
		int count=0;
		try {
			session=MyBatisUtil.getSqlSession();
			count=session.getMapper(NewsMapper.class).deleteNews(1000);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		
		log.debug("删除成功：-------------------->"+count);
	}
	
	
	
	
	
	
	
	//删除资讯信息
	@Test
	public void testDeleteNews2(){
		News news=new News();
		int count=0;
		count=new NewsServiceImpl().deleteNews(1000);
		
		log.debug("删除成功：-------------------->"+count);
	}
	
	
	
	
	
	
	
}
