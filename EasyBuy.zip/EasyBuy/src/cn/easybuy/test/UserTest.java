	package cn.easybuy.test;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;
import org.junit.Test;
import org.omg.CORBA.INTERNAL;

import cn.easybuy.service.user.UserServiceImpl;
import cn.easybuy.util.MyBatisUtil;
import cn.easybuy.util.Page;
import cn.easybuy.dao.user.UserMapper;
import cn.easybuy.pojo.User;

public class UserTest {
	private Logger log=Logger.getLogger(UserTest.class);
	
	//查询所有用户个数
	@Test
	public void testGetUserListCount(){
		SqlSession session=null;
		int num=0;
		try {
			session=MyBatisUtil.getSqlSession();
			num=session.getMapper(UserMapper.class).getUserListCount();
			log.debug("用户数据为:"+num);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
	}
	
	
	//查询所有用户列表
	@Test
	public void testTotalUserList(){
		SqlSession session=null;
		List<User>list=null;
		try {
			session=MyBatisUtil.getSqlSession();
			list=session.getMapper(UserMapper.class).totalUserList(0, 10);
			log.debug("用户数据为:"+list.size());
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		
	}
	
	
	//查询对应页数的用户列表
	@Test
	public void testTotalUserList2(){
		UserServiceImpl us=new UserServiceImpl();
		Page page=us.getUserList(2, 10);
		
		log.debug(page.getCurrPageNo());
		log.debug(page.getPageSize());
		log.debug(page.getTotalCount());
		log.debug("一共多少页："+page.getTotalPageCount());
		log.debug(page.getUserList().size());
	}
	
	
	
	// 根据id查询用户信息
	@Test
	public void testGetUserById(){
		SqlSession session=null;
		User user=null;
		try {
			session=MyBatisUtil.getSqlSession();
			user=session.getMapper(UserMapper.class).getUserById(2);
			log.debug("用户数据为:"+user.getUserName());
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
	}
	// 根据id查询用户信息
		@Test
		public void testGetUserById2(){
			User user=new UserServiceImpl().getUserById(2);
			log.debug("用户数据为:"+user.getUserName());

		}
		
		
		
		
		
		
		// 根据id查询用户信息
		@Test
		public void testGetUserByIdentityCode3(){
			int i=new UserServiceImpl().selectUserByLoginName("add");
			log.debug(i);

		}
		
		
		
		// 根据登录用户名查询用户是否存在
		@Test
		public void testGetUserByIdentityCode4(){
			SqlSession session=null;
			int count=0;
			
			try {
				session=MyBatisUtil.getSqlSession();
				count=session.getMapper(UserMapper.class).selectUserByLoginName("add");
				log.debug(count);
			} catch (Exception e) {
				e.printStackTrace();
			}finally{
				if(session!=null){
					session.close();
				}
			}
			log.debug(count);

		}
		
		
		//增加用户信息
		@Test
		public void testAddUser(){
			SqlSession session=null;
			int count=0;
			User user=new User();
			user.setLoginName("xm");
			user.setUserName("小明");
			user.setPassword("123123");
			user.setEmail("123@qq.com");
			user.setIdentityCode("123412341234123412");
			user.setMobile("12312312312");
			user.setSex(1);
			user.setType(1);
			try {
				session=MyBatisUtil.getSqlSession();
				count=session.getMapper(UserMapper.class).addUser(user);
				log.debug(count);
			} catch (Exception e) {
				e.printStackTrace();
			}finally{
				if(session!=null){
					session.close();
				}
			}
			log.debug(count);
		}
		
		
		
		//增加用户信息
		@Test
		public void testAddUser2(){
			SqlSession session=null;
			int count=0;
			User user=new User();
			user.setLoginName("xm");
			user.setUserName("小明");
			user.setPassword("123123");
			user.setEmail("123@qq.com");
			user.setIdentityCode("123412341234123412");
			user.setMobile("12312312312");
			user.setSex(1);
			user.setType(1);
			count=new UserServiceImpl().addUser(user);
			log.debug(count);
		}
		
		
		

		//修改用户信息
		@Test
		public void testUpdateUser(){
			SqlSession session=null;
			int count=0;
			User user=new User();
			user.setId(30);
			user.setLoginName("xm");
			user.setUserName("小明");
			user.setPassword("123123");
			user.setEmail("123@qq.com");
			user.setIdentityCode("123412341234123412");
			user.setMobile("12312312312");
			user.setSex(1);
			user.setType(1);
			try {
				session=MyBatisUtil.getSqlSession();
				count=session.getMapper(UserMapper.class).updateUser(user);
				log.debug(count);
			} catch (Exception e) {
				e.printStackTrace();
			}finally{
				if(session!=null){
					session.close();
				}
			}
			log.debug(count);
		}
		
		
		
		
		//修改用户信息
		@Test
		public void testUpdateUser2(){
			int count=0;
			User user=new User();
			user.setId(30);
			user.setLoginName("xm");
			user.setUserName("小明");
			user.setPassword("123123");
			user.setEmail("123@qq.com");
			user.setIdentityCode("123412341234123412");
			user.setMobile("12312312312");
			user.setSex(1);
			user.setType(1);
			count=new UserServiceImpl().updateUser(user);
			log.debug(count);
		}
		
		
		
		
		
		//删除用户信息
		@Test
		public void testDeleteUser(){
			SqlSession session=null;
			int count=0;
			try {
				session=MyBatisUtil.getSqlSession();
				count=session.getMapper(UserMapper.class).deleteUser(100);
				log.debug(count);
			} catch (Exception e) {
				e.printStackTrace();
			}finally{
				if(session!=null){
					session.close();
				}
			}
			log.debug(count);
		}
		
		
		
		//删除用户信息
		@Test
		public void testDeleteUser2(){
			int count=0;
			count=new UserServiceImpl().deleteUser(100);
			log.debug(count);
		}
}
