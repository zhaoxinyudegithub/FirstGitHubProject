package cn.easybuy.test;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;
import org.junit.Test;

import cn.easybuy.dao.orderdetail.OrderDetailMapper;
import cn.easybuy.dao.user.UserMapper;
import cn.easybuy.pojo.OrderDetail;
import cn.easybuy.pojo.User;
import cn.easybuy.service.orderdetail.OrderDetailServiceImpl;
import cn.easybuy.util.MyBatisUtil;

public class OrderDetailTest {
	Logger log=Logger.getLogger(OrderDetailTest.class);
	
	
	//添加订单详细信息
	@Test
	public void testAddOrderDetail(){
		SqlSession session=null;
		int count=0;
		OrderDetail orderDetail=new OrderDetail();
		orderDetail.setOrderId(1);
		orderDetail.setProductId(788);
		orderDetail.setQuantity(1);
		orderDetail.setCost(123);
		try {
			session=MyBatisUtil.getSqlSession();
			count=session.getMapper(OrderDetailMapper.class).addOrderDetail(orderDetail);
			log.debug(count);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		log.debug(count);
	}
	
	
	
	
	
	//添加订单详细信息
	@Test
	public void testAddOrderDetail2(){
		int count=0;
		OrderDetail orderDetail=new OrderDetail();
		orderDetail.setOrderId(1);
		orderDetail.setProductId(788);
		orderDetail.setQuantity(1);
		orderDetail.setCost(123);
		count=new OrderDetailServiceImpl().addOrderDetail(orderDetail);
		log.debug(count);
	}




	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
