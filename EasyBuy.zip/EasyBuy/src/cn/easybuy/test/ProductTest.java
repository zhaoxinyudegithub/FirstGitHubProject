package cn.easybuy.test;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;
import org.junit.Test;

import cn.easybuy.dao.product.ProductMapper;
import cn.easybuy.dao.user.UserMapper;
import cn.easybuy.pojo.Product;
import cn.easybuy.service.product.ProductServiceImpl;
import cn.easybuy.util.MyBatisUtil;
import cn.easybuy.util.Page;

public class ProductTest {
	Logger log=Logger.getLogger(ProductTest.class);
	
	//查询全部商品信息数量
	@Test
	public void testGetProductListCount(){
		SqlSession session=null;
		int num=0;
		try {
			session=MyBatisUtil.getSqlSession();
			num=session.getMapper(ProductMapper.class).getProductListCount();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		
		log.debug("商品数量-------》"+num);

	}
	
	
	//查询全部商品信息数量
	@Test
	public void testGetProductListCount2(){
		int num=0;
		num=new ProductServiceImpl().getProductListCount();
		log.debug("商品数量-------》"+num);

	}
	
	
	
	
	
	//查询全部商品信息
	@Test
	public void testSelectProductList(){
		SqlSession session=null;
		int num=0;
		List<Product>list=null;
		try {
			session=MyBatisUtil.getSqlSession();
			list=session.getMapper(ProductMapper.class).selectProductList(15,15);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		
		for (Product product : list) {
			log.debug("商品名称-------》"+product.getName());
			log.debug("商品图片-------》"+product.getFileName());
			log.debug("库存-------》"+product.getStock());
			log.debug("价格-------》"+product.getPrice());
			log.debug("");
		}
	}
	
	
	
	
	//查询全部商品信息
	@Test
	public void testSelectProductList2(){
		Page page=new Page();
		page=new ProductServiceImpl().selectProductList(2,15);
		
		for (Product product : page.getProductList()) {
			log.debug("商品名称-------》"+product.getName());
			log.debug("商品图片-------》"+product.getFileName());
			log.debug("库存-------》"+product.getStock());
			log.debug("价格-------》"+product.getPrice());
			log.debug("");
		}
	}
	
	
	
	//根据商品id查询商品信息 
	@Test
	public void testSelectProductById(){
		SqlSession session=null;
		Product product=null;
		try {
			session=MyBatisUtil.getSqlSession();
			product=session.getMapper(ProductMapper.class).selectProductById(733);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		log.debug("商品名称-------》"+product.getName());
	}
	
	
	
	
	//根据商品id查询商品信息 
	@Test
	public void testSelectProductById2(){
		Product product=null;
		product=new ProductServiceImpl().selectProductById(733);
		log.debug("商品名称-------》"+product.getName());
	}
	
	
	
	

	//根据商品名称查询商品信息 是否存在
	@Test
	public void testSelectProductNameIsHave(){
		SqlSession session=null;
		int num=0;
		try {
			session=MyBatisUtil.getSqlSession();
			num=session.getMapper(ProductMapper.class).selectProductNameIsHave("香奈儿");
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		log.debug("商品是否存在-------》"+num);
	}
	
	
	
	//根据商品名称查询商品信息 是否存在
	@Test
	public void testSelectProductNameIsHave2(){
		int num=0;
		num=new ProductServiceImpl().selectProductNameIsHave("香水");
		log.debug("商品是否存在-------》"+num);
	}
	
	
	
	
	
	
	//增加商品信息
	@Test
	public void testAddProduct(){
		SqlSession session=null;
		Product product=new Product();
		product.setName("哈哈哈");
		product.setCategoryLevel1Id(548);
		product.setCategoryLevel2Id(654);
		product.setCategoryLevel3Id(655);
		product.setFileName("哈哈哈.png");
		product.setPrice(12);
		product.setStock(12);
		product.setDescription("你好");
		product.setIsDelete(0);
		int num=0;
		try {
			session=MyBatisUtil.getSqlSession();
			num=session.getMapper(ProductMapper.class).addProduct(product);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		log.debug("添加是否成功-------》"+num);
	}
	
	
	
	
	
	
	
	
	//增加商品信息
	@Test
	public void testAddProduct2(){
		Product product=new Product();
		product.setName("哈哈哈");
		product.setCategoryLevel1Id(548);
		product.setCategoryLevel2Id(654);
		product.setCategoryLevel3Id(655);
		product.setFileName("哈哈哈.png");
		product.setPrice(12);
		product.setStock(12);
		product.setDescription("你好");
		product.setIsDelete(0);
		int num=0;
		num=new ProductServiceImpl().addProduct(product);
		log.debug("添加是否成功-------》"+num);
	}
	
	
	
	
	
	
	
	//修改商品信息
	@Test
	public void testUpdateProduct(){
		SqlSession session=null;
		Product product=new Product();
		product.setId(774);
		product.setName("哈哈哈");
		product.setCategoryLevel1Id(548);
		product.setCategoryLevel2Id(654);
		product.setCategoryLevel3Id(655);
		product.setFileName("哈哈哈.png");
		product.setPrice(12);
		product.setStock(12);
		product.setDescription("你好");
		product.setIsDelete(0);
		int num=0;
		try {
			session=MyBatisUtil.getSqlSession();
			num=session.getMapper(ProductMapper.class).updateProduct(product);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		log.debug("添加修改成功-------》"+num);
	}
	
	
	
	
	
	//修改商品信息
	@Test
	public void testUpdateProduct2(){
		Product product=new Product();
		product.setId(774);
		product.setName("呵呵");
		product.setCategoryLevel1Id(548);
		product.setCategoryLevel2Id(654);
		product.setCategoryLevel3Id(655);
		product.setFileName("哈哈哈.png");
		product.setPrice(12);
		product.setStock(12);
		product.setDescription("你好");
		product.setIsDelete(0);
		int num=0;
		num=new ProductServiceImpl().updateProduct(product);
		log.debug("添加修改成功-------》"+num);
	}
	
	
	
	
	//是否存在某张商品图片
	@Test
	public void testIsHaveProductImg(){
		SqlSession session=null;
		int num=0;
		try {
			session=MyBatisUtil.getSqlSession();
			num=session.getMapper(ProductMapper.class).isHaveProductImg("his_5.jpg");
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		log.debug("商品图是否存在-------》"+num);
	}
	
	
	
	
	
	//是否存在某张商品图片
	@Test
	public void testIsHaveProductImg2(){
		int num=0;
		num=new ProductServiceImpl().isHaveProductImg("his_5.jpg");
		log.debug("商品图是否存在-------》"+num);
	}
		
	
	
	
	//删除商品信息
	@Test
	public void testDeleteProduct(){
		SqlSession session=null;
		int num=0;
		try {
			session=MyBatisUtil.getSqlSession();
			num=session.getMapper(ProductMapper.class).deleteProduct(1);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		log.debug("删除成功-------》"+num);
	}
	
	
	
	
	
	//删除商品信息
	@Test
	public void testDeleteProduct2(){
		int num=0;
		num=new ProductServiceImpl().deleteProduct(2);
		log.debug("删除成功-------》"+num);
	}
	
	
	
	
	
	
	
	//根据商品名称模糊查询商品名称
	@Test
	public void testSelectProductNameByProductName(){
		SqlSession session=null;
		List<String>nameList=null;
		try {
			session=MyBatisUtil.getSqlSession();
			nameList=session.getMapper(ProductMapper.class).selectProductNameByProductName("香");
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		for (String string : nameList) {
			log.debug("商品名称-------》"+string);
		}
	}
	
	
	
	
	
	

	
	
	
	
	
	
	//根据商品名称模糊查询商品集合
	@Test
	public void testSelectProductListByProductName(){
		SqlSession session=null;
		List<Product>nameList=null;
		try {
			session=MyBatisUtil.getSqlSession();
			nameList=session.getMapper(ProductMapper.class).selectProductListByProductName("香");
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		for (Product product : nameList) {
			log.debug("商品名称-------》"+product.getName());
		}
	}
	
	
	//根据商品名称模糊查询商品名称
	@Test
	public void testSelectProductListByProductName2(){
		List<Product>nameList=null;
		nameList=new ProductServiceImpl().selectProductListByProductName("香");
		for (Product product : nameList) {
			log.debug("商品名称-------》"+product.getName());
		}
	}
	
	
	
	
	//根据商品名称模糊查询商品名称
	@Test
	public void testSelectProductNameByProductName2(){
		List<String>nameList=null;
		nameList=new ProductServiceImpl().selectProductNameByProductName("香");
		for (String string : nameList) {
			log.debug("商品名称-------》"+string);
		}
	}
		
	
	
	
	//查询全部商品信息
	@Test
	public void testSelectProductListLimit3(){
		SqlSession session=null;
		int num=0;
		List<Product>list=null;
		try {
			session=MyBatisUtil.getSqlSession();
			list=session.getMapper(ProductMapper.class).selectProductListLimit3();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		
		for (Product product : list) {
			log.debug("商品名称-------》"+product.getName());
			log.debug("商品图片-------》"+product.getFileName());
			log.debug("库存-------》"+product.getStock());
			log.debug("价格-------》"+product.getPrice());
			log.debug("");
		}
	}
	
	
	
	
	
	
	
	//查询全部商品信息
	@Test
	public void testSelectProductListLimit32(){
		List<Product>list=null;
		list=new ProductServiceImpl().selectProductListLimit3();
		for (Product product : list) {
			log.debug("商品名称-------》"+product.getName());
			log.debug("商品图片-------》"+product.getFileName());
			log.debug("库存-------》"+product.getStock());
			log.debug("价格-------》"+product.getPrice());
			log.debug("");
		}
	}
	
	
	
	
	
	
	
	//查询全部商品信息数量
	@Test
	public void testSelectProductListByCategory1Limit12(){
		SqlSession session=null;
		int num=0;
		List<Product>list=null;
		try {
			session=MyBatisUtil.getSqlSession();
			list=session.getMapper(ProductMapper.class).selectProductListByCategory1Limit12(548);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		
		log.debug("商品数量-------》"+list.size());

	}
	
	
	
	
	//查询全部商品信息数量
	@Test
	public void testSelectProductListByCategory1Limit12_2(){
		List<Product>list=null;
		list=new ProductServiceImpl().selectProductListByCategory1Limit12(548);
		
		log.debug("商品数量-------》"+list.size());

	}
	
	
	
	
	
	
	//根据一级分类查询所有商品信息
	@Test
	public void testSelectProductListByCategory1(){
		SqlSession session=null;
		int num=0;
		List<Product>list=null;
		try {
			session=MyBatisUtil.getSqlSession();
			list=session.getMapper(ProductMapper.class).selectProductListByCategory1(548);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		
		log.debug("商品数量-------》"+list.size());

	}
	
	
	
	
	
	
	
	//查询全部商品信息数量
	@Test
	public void testSelectProductListByCategory1_2(){
		List<Product>list=null;
		list=new ProductServiceImpl().selectProductListByCategory1(548);
		
		log.debug("商品数量-------》"+list.size());

	}
	
	
	
	
	
	
	//根据二级分类查询所有商品信息
	@Test
	public void testSelectProductListByCategory2(){
		SqlSession session=null;
		int num=0;
		List<Product>list=null;
		try {
			session=MyBatisUtil.getSqlSession();
			list=session.getMapper(ProductMapper.class).selectProductListByCategory2(654);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		
		log.debug("商品数量-------》"+list.size());

	}
	
	
	
	//根据二级分类查询所有商品信息
	@Test
	public void testSelectProductListByCategory2_2(){
		List<Product>list=null;
		list=new ProductServiceImpl().selectProductListByCategory2(637);
		
		log.debug("商品数量-------》"+list.size());

	}
	
	
	
	
	
	//根据三级分类查询所有商品信息
	@Test
	public void testSelectProductListByCategory3(){
		SqlSession session=null;
		int num=0;
		List<Product>list=null;
		try {
			session=MyBatisUtil.getSqlSession();
			list=session.getMapper(ProductMapper.class).selectProductListByCategory3(688);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		
		log.debug("商品数量-------》"+list.size());

	}
	
	
	
	
	
	//根据三级分类查询所有商品信息
	@Test
	public void testSelectProductListByCategory3_2(){
		List<Product>list=null;
		list=new ProductServiceImpl().selectProductListByCategory3(688);
		
		log.debug("商品数量-------》"+list.size());

	}
	
	
	
	
	
	
}
