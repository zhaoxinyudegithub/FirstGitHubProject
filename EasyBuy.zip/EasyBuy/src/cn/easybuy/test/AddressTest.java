package cn.easybuy.test;

import static org.junit.Assert.*;

import java.sql.Date;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;
import org.junit.Test;

import cn.easybuy.dao.address.AddressMapper;
import cn.easybuy.dao.user.UserMapper;
import cn.easybuy.pojo.Address;
import cn.easybuy.pojo.User;
import cn.easybuy.service.address.AddressServiceImpl;
import cn.easybuy.service.user.UserServiceImpl;
import cn.easybuy.servlet.newCarServlet;
import cn.easybuy.util.MyBatisUtil;

public class AddressTest {
	private Logger log=Logger.getLogger(UserTest.class);
		//根据id查询用户信息
			@Test
			public void testToselectAddress(){
				SqlSession session=null;
				List<Address> address=null;
				try {
					session=MyBatisUtil.getSqlSession();
					address=session.getMapper(AddressMapper.class).toselectAddress(2);
					for (Address address2 : address) {
					log.debug("用户数据为:"+address2.getAddress());
					}
			
				} catch (Exception e) {
					e.printStackTrace();
				}finally{
					if(session!=null){
						session.close();
					}
				}
			}
			// 根据id查询用户信息
			@Test
			public void testToselectAddress2(){
				List<Address> address=new AddressServiceImpl().toselectAddress(2);
				for (Address address2 : address) {
					log.debug("用户数据为:"+address2.getAddress());
				}
			}
			
			//根据地址id修改用户信息(1)
			@Test
			public void testUpdateAddress(){
				SqlSession session=null;
				int count=0;
				Address address=new Address();
				try {
					session=MyBatisUtil.getSqlSession();
					count=session.getMapper(AddressMapper.class).toupdateAddress(11);
					log.debug(count);
				} catch (Exception e) {
					e.printStackTrace();
				}finally{
					if(session!=null){
						session.close();
					}
				}
				log.debug(count);
			}
			
			@Test
			public void testUpdateAddress2(){
				int count=0;
				count=new AddressServiceImpl().toupdateAddress(13);
				log.debug(count);

			}
			//根据用户id修改信息(0)
			@Test
			public void testUpdateUser(){
				SqlSession session=null;
				int count=0;
				Address address=new Address();
				try {
					session=MyBatisUtil.getSqlSession();
					count=session.getMapper(AddressMapper.class).toupdateUser(9);
					log.debug(count);
				} catch (Exception e) {
					e.printStackTrace();
				}finally{
					if(session!=null){
						session.close();
					}
				}
				log.debug(count);
			}
			
			@Test
			public void testUpdateUser2(){
				int count=0;
				count=new AddressServiceImpl().toupdateUser(18);
				log.debug(count);

			}
			
			//根据地址和用户id修改默认地址
			@Test
			public void testupdateAddress(){
				int count=0;
				count=new AddressServiceImpl().updateAddress(18,14);
				log.debug(count);

			}
			
			//根据用户id增加信息
			@Test
			public void testaddAddress(){
				SqlSession session=null;
				int count=0;
				Address address=new Address();
				address.setUserId(9);
				address.setAddress("北京市西直门大桥");
				address.setCreateTime(new java.util.Date());
				address.setIsDefault(1);
				try {
					session=MyBatisUtil.getSqlSession();
					count=session.getMapper(AddressMapper.class).addAdress(address);
					log.debug(count);
				} catch (Exception e) {
					e.printStackTrace();
				}finally{
					if(session!=null){
						session.close();
					}
				}
				log.debug(count);
			}
			
			@Test
			public void testaddAddress2(){
				int count=0;
				Address address=new Address();
				address.setUserId(9);
				address.setAddress("北京市海淀区大好庄");
				address.setCreateTime(new java.util.Date());
				address.setIsDefault(1);
				count=new AddressServiceImpl().addAdress(address);
				log.debug(count);
			}
			//根据地址id删除信息
			@Test
			public void testdeleteAddress(){
				SqlSession session=null;
				int count=0;
				try {
					session=MyBatisUtil.getSqlSession();
					count=session.getMapper(AddressMapper.class).deleteAddress(27);
					log.debug(count);
				} catch (Exception e) {
					e.printStackTrace();
				}finally{
					if(session!=null){
						session.close();
					}
				}
				log.debug(count);
			}
			@Test
			public void testdeleteAddress2(){
				int count=0;
				count=new AddressServiceImpl().deleteAddress(28);
				log.debug(count);
			}

}

