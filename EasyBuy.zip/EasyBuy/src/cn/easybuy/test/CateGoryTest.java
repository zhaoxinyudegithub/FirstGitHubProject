package cn.easybuy.test;

import static org.junit.Assert.*;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;
import org.junit.Test;

import com.sun.org.apache.bcel.internal.generic.NEW;

import cn.easybuy.dao.category.CateGoryMapper;
import cn.easybuy.dao.user.UserMapper;
import cn.easybuy.pojo.Category;
import cn.easybuy.service.category.CateGoryServiceImpl;
import cn.easybuy.util.MyBatisUtil;
import cn.easybuy.util.Page;

public class CateGoryTest {
	private Logger log=Logger.getLogger(CateGoryTest.class);
	
	
	
	//查询分类信息总数
	@Test
	public void testSelectCategoryCount() {
		SqlSession session=null;
		int count=0;
		try {
			session=MyBatisUtil.getSqlSession();
			count=session.getMapper(CateGoryMapper.class).selectCategoryCount();
			log.debug("分类总量为:"+count);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
	}
	
	
	
	
	
	//查询分类信息总数
		@Test
		public void testSelectCategoryCount2() {
			int count=0;
			count=new CateGoryServiceImpl().selectCategoryCount();
			log.debug("分类总量为:"+count);
		}
		
		
	
	
	
	
	//查询所有分类信息
	@Test
	public void testSelectCategoryTotalList() {
		SqlSession session=null;
		List<Category>list=null;
		try {
			session=MyBatisUtil.getSqlSession();
			list=session.getMapper(CateGoryMapper.class).selectCategoryTotalList(0,15);
			log.debug("分类总量为:"+list.size());
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
	}
	
	
	
	
	//查询所有分类信息
	@Test
	public void testSelectCategoryTotalList2() {
		Page page=new CateGoryServiceImpl().selectCategoryTotalList(2,15);
		log.debug("当前页码为："+page.getCurrPageNo());
		log.debug("页码数量为："+page.getPageSize());
		log.debug("总页码数为："+page.getTotalPageCount());
		for (Category category : page.getCategoryList()) {
			log.debug("分类名称包括:"+category.getName()+"          父类类型为："+category.getParentName());

		}
	}
	
	
	
	
	//按等级查询分类信息
	@Test
	public void testSelectCategoryByType() {
		SqlSession session=null;
		List<Category>list=null;
		try {
			session=MyBatisUtil.getSqlSession();
			list=session.getMapper(CateGoryMapper.class).selectCategoryByType(1);
			log.debug("分类总量为:"+list.size());
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
	}
	
	
	
	
	
	//按等级查询分类信息
	@Test
	public void testSelectCategoryByType2() {
		List<Category>list=null;
		list=new CateGoryServiceImpl().selectCategoryByType(1);
		log.debug("分类总量为:"+list.size());
	}
	
	
	
	
	//根据分类id查询分类信息
	@Test
	public void testSelectCategoryById() {
		SqlSession session=null;
		Category category=null;
		try {
			session=MyBatisUtil.getSqlSession();
			category=session.getMapper(CateGoryMapper.class).selectCategoryById(654);
			log.debug("分类名称为："+category.getName());
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
	}
	
	
	
	
	
	//根据分类id查询分类信息
	@Test
	public void testSelectCategoryById2() {
		Category category=null;
		category=new CateGoryServiceImpl().selectCategoryById(654);
		log.debug("分类名称为："+category.getName());
	}
	
	
	
	
	
	
	//根据分类名称分类名称是否存在
	@Test
	public void testSelectCategoryByName() {
		SqlSession session=null;
		int count=0;
		try {
			session=MyBatisUtil.getSqlSession();
			count=session.getMapper(CateGoryMapper.class).selectCategoryByName("家用商品");
			log.debug("分类名称是否存在："+count);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
	}
	
	
	
	
	
	
	
	//根据分类名称分类名称是否存在
	@Test
	public void testSelectCategoryByName2() {
		int count=0;
		count=new CateGoryServiceImpl().selectCategoryByName("家用商品");
		log.debug("分类名称是否存在："+count);
	}
	
	
	
	
	
	
	//查询分类图片是否已经存在
	@Test
	public void testSelectCategoryByIconClass() {
		SqlSession session=null;
		int count=0;
		try {
			session=MyBatisUtil.getSqlSession();
			count=session.getMapper(CateGoryMapper.class).selectCategoryByIconClass("电脑.png");
			log.debug("分类图片是否存在："+count);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
	}
	
	
	
	
	
	
	
	//查询分类图片是否已经存在
	@Test
	public void testSelectCategoryByIconClass2() {
		int count=0;
		count=new CateGoryServiceImpl().selectCategoryByIconClass("电脑.png");
		log.debug("分类图片是否存在："+count);
	}
	
	
	
	
	
	
	
	//增加分类信息
	@Test
	public void testAddCategory() {
		SqlSession session=null;
		int count=0;
		Category category=new Category();
		category.setName("傻蛋");
		category.setParentId(0);
		category.setType(1);
		category.setIconClass("傻蛋.png");
		try {
			session=MyBatisUtil.getSqlSession();
			count=session.getMapper(CateGoryMapper.class).addCategory(category);
			log.debug("增加是否成功："+count);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
	}
	
	
	
	
	
	
	
	//增加分类信息
	@Test
	public void testAddCategory2() {
		int count=0;
		Category category=new Category();
		category.setName("傻比");
		category.setParentId(0);
		category.setType(1);
		category.setIconClass("傻比.png");
		count=new CateGoryServiceImpl().addCategory(category);
		log.debug("增加是否成功："+count);
	}
	
	
	
	
	
	
	//修改分类信息
	@Test
	public void testUpdateCategory() {
		SqlSession session=null;
		int count=0;
		Category category=new Category();
		category.setId(700);
		category.setName("傻逼");
		category.setParentId(0);
		category.setType(1);
		category.setIconClass("傻逼.png");
		try {
			session=MyBatisUtil.getSqlSession();
			count=session.getMapper(CateGoryMapper.class).updateCategory(category);
			log.debug("修改是否成功："+count);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
	}

	
	
	
	
	
	
	
	//修改分类信息
	@Test
	public void testUpdateCategory2() {
		SqlSession session=null;
		int count=0;
		Category category=new Category();
		category.setId(700);
		category.setName("傻逼");
		category.setParentId(0);
		category.setType(1);
		category.setIconClass("傻逼.png");
		try {
			session=MyBatisUtil.getSqlSession();
			count=session.getMapper(CateGoryMapper.class).updateCategory(category);
			log.debug("修改是否成功："+count);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
	}

		
	
	
	
	
	
	
	//删除选中数组中的分类
	@Test
	public void testDeleteCategoryByIds() {
		SqlSession session=null;
		int count=0;
		int[]ids={701,702,703,704};
		try {
			session=MyBatisUtil.getSqlSession();
			count=session.getMapper(CateGoryMapper.class).deleteCategoryByIds(ids);
			log.debug("修改是否成功："+count);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
	}
	
	
	
	
	
	
	
	
	//删除选中数组中的分类
	@Test
	public void testDeleteCategoryByIds2() {
		int count=0;
		int[]ids={701,702,703,704};
		count=new CateGoryServiceImpl().deleteCategoryByIds(ids);
		log.debug("修改是否成功："+count);
	}
	
	
	
	
	
	
	
	//根据父类分类id查询子类集合
	@Test
	public void testSelectCategoryListByParentId() {
		SqlSession session=null;
		List<Category>list=null;
		try {
			session=MyBatisUtil.getSqlSession();
			list=session.getMapper(CateGoryMapper.class).selectCategoryListByParentId(548);
			log.debug("分类总量为:"+list.size());
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
	}
	
	
	
	
	
	
	
	
	//根据父类分类id查询子类集合
	@Test
	public void testSelectCategoryListByParentId2() {
		List<Category>list=null;
			list=new CateGoryServiceImpl().selectCategoryListByParentId(651);
			log.debug("分类总量为:"+list.size());
	}
	
	
	
	
	
	//根据父父类分类id查询子类集合
	@Test
	public void testSelectCategoryListByParentPrentId() {
		List<Category>list=null;
			list=new CateGoryServiceImpl().selectCategoryListByParentPrentId(660);
			log.debug("分类总量为:"+list.size());
	}
	
	

}
