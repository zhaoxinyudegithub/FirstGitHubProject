package cn.easybuy.test;

import static org.junit.Assert.*;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;
import org.junit.Test;

import cn.easybuy.dao.buycar.BuyCarMapper;
import cn.easybuy.dao.category.CateGoryMapper;
import cn.easybuy.pojo.BuyCar;
import cn.easybuy.service.buycar.BuyCarServiceImpl;
import cn.easybuy.util.MyBatisUtil;

public class BuyCarTest {
	Logger log=Logger.getLogger(BuyCarTest.class);
	
	
	//增加购物车记录
	@Test
	public void testAddBuyCar() {
		SqlSession session=null;
		int count=0;
		BuyCar buyCar=new BuyCar();
		buyCar.setUserId(1);
		buyCar.setProductId(733);
		buyCar.setNumber(1);
		buyCar.setSumPrice(1000);
		try {
			session=MyBatisUtil.getSqlSession();
			count=session.getMapper(BuyCarMapper.class).addBuyCar(buyCar);
			log.debug("插入成功:"+count);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
	}
	
	
	
	
	

	//增加购物车记录
	@Test
	public void testAddBuyCar2() {
		int count=0;
		BuyCar buyCar=new BuyCar();
		buyCar.setUserId(1);
		buyCar.setProductId(733);
		buyCar.setNumber(1);
		buyCar.setSumPrice(1000);
		count=new BuyCarServiceImpl().addBuyCar(buyCar);
		log.debug("插入成功:"+count);
	}
	
	
	
	
	//查询对应用户的购物记录
	@Test
	public void testSelectBuyCarListByUserId() {
		SqlSession session=null;
		List<BuyCar>list=null;
		try {
			session=MyBatisUtil.getSqlSession();
			list=session.getMapper(BuyCarMapper.class).selectBuyCarListByUserId(2);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		for (BuyCar buyCar : list) {
			log.debug("商品名称为:"+buyCar.getProduct().getName());
			log.debug("商品单价为:"+buyCar.getProduct().getPrice());
			log.debug("商品数量为:"+buyCar.getNumber());
			log.debug("商品总价格为:"+buyCar.getSumPrice());
			log.debug("");
			
		}
		
	}
	
	
	
	
	
	
	//查询对应用户的购物记录
	@Test
	public void testSelectBuyCarListByUserId2() {
		List<BuyCar>list=null;
		list=new BuyCarServiceImpl().selectBuyCarListByUserId(2);
		for (BuyCar buyCar : list) {
			log.debug("商品名称为:"+buyCar.getProduct().getName());
			log.debug("商品单价为:"+buyCar.getProduct().getPrice());
			log.debug("商品数量为:"+buyCar.getNumber());
			log.debug("商品总价格为:"+buyCar.getSumPrice());
			log.debug("");
			
		}
		
	}
	
	
	//根据用户id清空购物车
	@Test
	public void testDeleteBuyCar() {
		SqlSession session=null;
		int count=0;
		try {
			session=MyBatisUtil.getSqlSession();
			count=session.getMapper(BuyCarMapper.class).deleteBuyCar(3);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		log.debug(count);
	}
	
	
	
	
	//根据用户id清空购物车
	@Test
	public void testDeleteBuyCar2() {
		int count=0;
		count=new BuyCarServiceImpl().deleteBuyCar(3);
		log.debug(count);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
