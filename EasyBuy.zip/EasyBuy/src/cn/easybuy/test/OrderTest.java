package cn.easybuy.test;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;
import org.junit.Test;

import cn.easybuy.dao.order.OrderMapper;
import cn.easybuy.dao.user.UserMapper;
import cn.easybuy.pojo.Order;
import cn.easybuy.pojo.OrderDetail;
import cn.easybuy.service.order.OrderServiceImpl;
import cn.easybuy.util.MyBatisUtil;

public class OrderTest {
	Logger log=Logger.getLogger(OrderTest.class);
	
	
	
	
	
	//查询全部订单信息
	@Test
	public void testSelectTotalOrder(){
		SqlSession session=null;
		int num=0;
		List<Order> list=null;
		try {
			session=MyBatisUtil.getSqlSession();
			list=session.getMapper(OrderMapper.class).selectTotalOrder();
			log.debug("用户数据为:"+num);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		if(list==null){
			System.out.println(list);
		}else {
			for (Order order : list) {
				System.out.println("orderId--------------->"+order.getId());
				for (OrderDetail od : order.getOrderDetailsList()) {
					System.out.println(od.getProduct().getName());
				}
			}
			System.out.println();
		}
	}
	
	
	
	
	
	
	//查询全部订单信息
	@Test
	public void testSelectTotalOrder2(){
		List<Order> list=null;
		list=new OrderServiceImpl().selectTotalOrder();
		if(list==null){
			System.out.println(list);
		}else {
			for (Order order : list) {
				System.out.println("orderId--------------->"+order.getId());
				for (OrderDetail od : order.getOrderDetailsList()) {
					System.out.println(od.getProduct().getName());
				}
			}
			System.out.println();
		}
	}




	
	
	//按照订单号和登录用户名查询订单信息
	@Test
	public void testSelectOrderBySerialNumberAndLoginName(){
		SqlSession session=null;
		List<Order> list=null;
		String serialNumber="";
		String loginName="shangzezhong";
		try {
			session=MyBatisUtil.getSqlSession();
			list=session.getMapper(OrderMapper.class).selectOrderBySerialNumberAndLoginName(serialNumber, loginName);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		if(list==null){
			System.out.println(list);
		}else {
			for (Order order : list) {
				System.out.println("orderId--------------->"+order.getId());
				for (OrderDetail od : order.getOrderDetailsList()) {
					System.out.println(od.getProduct().getName());
				}
			}
			System.out.println();
		}
	}
	
	
	
	
	
	
	//按照订单号和登录用户名查询订单信息
	@Test
	public void testSelectOrderBySerialNumberAndLoginName2(){
		SqlSession session=null;
		List<Order> list=null;
		String serialNumber="";
		String loginName="";
		list=new OrderServiceImpl().selectOrderBySerialNumberAndLoginName(serialNumber, loginName);
		if(list==null){
			System.out.println(list);
		}else {
			for (Order order : list) {
				System.out.println("orderId--------------->"+order.getId());
				for (OrderDetail od : order.getOrderDetailsList()) {
					System.out.println(od.getProduct().getName());
				}
			}
			System.out.println();
		}
	}





	//增加充值电话订单
	@Test
	public void testAddPhoneOrder(){
		SqlSession session=null;
		int count=0;
		Order order=new Order();
		order.setUserId(2);
		order.setLoginName("admin");
		order.setUserAddress("北京市海淀区大有庄");
		order.setCreateTime(new java.util.Date());
		order.setCost(10);
		order.setSerialNumber("12312313132123131321");
		try {
			session=MyBatisUtil.getSqlSession();
			count=session.getMapper(OrderMapper.class).addPhoneOrder(order);
			log.debug(count);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		log.debug(count);
	}
	
	
	
	
	//增加充值电话订单
	@Test
	public void testAddPhoneOrder2(){
		int count=0;
		Order order=new Order();
		order.setUserId(2);
		order.setLoginName("admin");
		order.setUserAddress("北京市海淀区大有庄");
		order.setCreateTime(new java.util.Date());
		order.setCost(10);
		order.setSerialNumber("12312313132123131321");
		count=new OrderServiceImpl().addPhoneOrder(order);
		log.debug(count);
	}
	
	
	
	
	
	//查询最后增加订单的订单id
	@Test
	public void testSelectLastOrderId(){
		SqlSession session=null;
		int orderId=0;
		try {
			session=MyBatisUtil.getSqlSession();
			orderId=session.getMapper(OrderMapper.class).selectLastOrderId();
			log.debug(orderId);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		log.debug(orderId);
	}
	
	
	
	
	
	
	//查询最后增加订单的订单id
	@Test
	public void testSelectLastOrderId2(){
		int orderId=0;
		orderId=new OrderServiceImpl().selectLastOrderId();
		log.debug(orderId);
	}









}
