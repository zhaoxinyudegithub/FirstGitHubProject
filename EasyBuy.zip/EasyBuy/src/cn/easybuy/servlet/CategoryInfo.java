package cn.easybuy.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;

import cn.easybuy.pojo.Category;
import cn.easybuy.pojo.Product;
import cn.easybuy.pojo.User;
import cn.easybuy.service.category.CateGoryServiceImpl;
import cn.easybuy.service.product.ProductServiceImpl;
import cn.easybuy.service.user.UserServiceImpl;

/**
 * Servlet implementation class UserInfo
 */
@WebServlet("/categoryInfo")
public class CategoryInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		int id=Integer.parseInt(req.getParameter("id"));
		System.out.println("修改id-----》"+id);
		Category category=new CateGoryServiceImpl().selectCategoryById(id);
		String json=JSON.toJSONString(category);
		resp.getWriter().print(json);
		System.out.println(json);
	}
       
	


}
