package cn.easybuy.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;

import cn.easybuy.pojo.User;
import cn.easybuy.service.user.UserService;
import cn.easybuy.service.user.UserServiceImpl;
import cn.easybuy.util.Page;

/**
 * Servlet implementation class UserList
 */
@WebServlet("/userList")
public class UserList extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	
	@Override
	public void service(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		/*Integer currPageNo=Integer.parseInt(req.getParameter("currPageNo"));
		Integer pageSize=Integer.parseInt(req.getParameter("pageSize"));*/
		UserService us=new UserServiceImpl();
		int index=1;
		if(req.getParameter("index")==null){
			index=Integer.parseInt(req.getParameter("currPageNo"));
		}
		
		Page page=us.getUserList(index,15);
		
		//设置session当前页面
		req.getSession().setAttribute("userListIndex",index);
		
		String json=JSON.toJSONString(page);
		resp.getWriter().print(json);
	}
    

}
