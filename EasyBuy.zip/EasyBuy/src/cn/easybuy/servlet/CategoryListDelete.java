package cn.easybuy.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.easybuy.service.category.CateGoryServiceImpl;
import cn.easybuy.service.product.ProductServiceImpl;
import cn.easybuy.service.user.UserServiceImpl;

/**
 * Servlet implementation class UserDelete
 */
@WebServlet("/categoryListDelete")
public class CategoryListDelete extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String[]id1=req.getParameterValues("checkbox");
		if(id1==null){
			System.out.println(-1);
			resp.getWriter().print(-1);
		}else{
			int[] id = new int[id1.length];
			for(int i=0; i<id1.length; i++){
				id[i] = Integer.parseInt(id1[i]);
			}
			for(int i=0; i<id.length; i++){
				System.out.println("id---------->"+id[i]);
			}

			int count=new CateGoryServiceImpl().deleteCategoryByIds(id);
			System.out.println(count);
			resp.getWriter().print(count);
		}
		
	}

}
