package cn.easybuy.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.easybuy.pojo.BuyCar;
import cn.easybuy.pojo.User;
import cn.easybuy.service.buycar.BuyCarService;
import cn.easybuy.service.buycar.BuyCarServiceImpl;

import com.alibaba.fastjson.JSON;

/**
 * 数据库原数据显示在页面
 * Servlet implementation class newCarServlet
 */
@WebServlet("/newCarServlet2")
public class newCarServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter pw=resp.getWriter();
		BuyCarService ps=new BuyCarServiceImpl();
		int id=((User)(req.getSession().getAttribute("plainUser"))).getId();
		List<BuyCar> list=ps.selectBuyCarListByUserId(id);
		for (BuyCar buyCar : list) {
			System.out.println(buyCar.getProduct().getName());
		}
		//req.getSession().setAttribute("showInfo", list);
		//resp.sendRedirect("buyCar1.jsp");
		String js=JSON.toJSONString(list);
		System.out.println("购物车结算:"+js);
		pw.print(js);
		pw.close();
	}
	//修改数量
	protected void createNum(HttpServletRequest reqe, HttpServletResponse respo) throws Exception{
		BuyCar bc=new BuyCar();
		String id=reqe.getParameter("");//商品id
		String quantity=reqe.getParameter("car_ipt");
		Integer shopNum=Integer.parseInt(quantity);
		/*if ((id==null||id.equals("")) && (quantity==null||quantity.equals(""))) {
			System.out.println("参数不能为空");
			return;
		}*/
		BuyCarService ps=new BuyCarServiceImpl();
		List<BuyCar> list=ps.selectBuyCarListByUserId(1);
		for (BuyCar buyCar : list) {
			if (buyCar.getProduct().getStock()<shopNum) {
				System.out.println("商品数量不足");
				return;
			}
		}
		double price=list.get(1).getSumPrice();
		BuyCarService bcs=new BuyCarServiceImpl();
		bc=(BuyCar) bcs.newNum(1, shopNum, price);
		reqe.getSession().setAttribute("bc", bc);
	}

}
