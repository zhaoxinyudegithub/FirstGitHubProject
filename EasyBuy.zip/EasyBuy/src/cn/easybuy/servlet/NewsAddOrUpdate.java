package cn.easybuy.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.easybuy.pojo.News;
import cn.easybuy.pojo.User;
import cn.easybuy.service.news.NewsServiceImpl;
import cn.easybuy.service.user.UserServiceImpl;

/**
 * Servlet implementation class UserAddOrUpdate
 */
@WebServlet("/newsAddOrUpdate")
public class NewsAddOrUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//接受参数
		String title=req.getParameter("newsTitle");
		String content=req.getParameter("newsContent");
		
		int id=0;
		String id1=req.getParameter("id");
		
		System.out.println("id------->"+id);
		System.out.println("title------->"+title);
		System.out.println("content------->"+content);

		
		News news=new News();
		news.setTitle(title);
		news.setContent(content);
		
		int count=0;
		//判断是增加还是修改
		if(id1==null){	//增加
			System.out.println("增加");
			count=new NewsServiceImpl().addNews(news);
			System.out.println(count);
			resp.getWriter().print(count);
		}else{			//修改
			id=Integer.parseInt(id1);
			System.out.println("修改");
			news.setId(id);
			count=new NewsServiceImpl().updateNews(news);
			System.out.println(count);
			resp.getWriter().print(count);
		}
		
	}

}