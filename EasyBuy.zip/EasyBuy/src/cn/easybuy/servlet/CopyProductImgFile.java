package cn.easybuy.servlet;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadBase;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

/**
 * Servlet implementation class DisplayImage
 */
@WebServlet("/copyImgFile")
public class CopyProductImgFile extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		/*String fileName = req.getParameter("imgFile");
		System.out.println(fileName);

		try {
			int bytesum = 0;
			int byteread = 0;
			File oldfile = new File(fileName);
			InputStream inStream = new FileInputStream(fileName); // 读入原文件
			FileOutputStream fs = new FileOutputStream("C:/Users/fitting/Desktop/aa.jpg");
			byte[] buffer = new byte[1444];
			int length;
			while ((byteread = inStream.read(buffer)) != -1) {
				bytesum += byteread; // 字节数 文件大小
				System.out.println(bytesum);
				fs.write(buffer, 0, byteread);
			}
				inStream.close();
		} catch (Exception e) {
			System.out.println("复制单个文件操作出错");
			e.printStackTrace();

		}
*/
		
		
		
		
		
		
		
		
		// 三件套
		req.setCharacterEncoding("utf-8");
		resp.setCharacterEncoding("utf-8");
		resp.setContentType("text/html;charset=utf-8");
		
		//判断是否是文件表单 
		if(!ServletFileUpload.isMultipartContent(req)){
			System.out.println("这不是一个表单类型");
		}

		// 控制文件上传类型
		FileItemFactory fif = new DiskFileItemFactory();
		ServletFileUpload sfu = new ServletFileUpload(fif);
		List<String> fileType = Arrays.asList("png", "gif", "jpg");


		// 创建临时文件目录
		//设置缓冲区大小1kb3
		((DiskFileItemFactory)fif).setSizeThreshold(1024*100);
		//设置一个完整请求的最大允许大小
		//sfu.setSizeMax(1024*100);
		
		
		try {
			List<FileItem> list = sfu.parseRequest(req);
			
			
			//iterator遍历
			Iterator<FileItem>items=list.iterator();
			while(items.hasNext()){
				//拿到每一个items对象
				FileItem fileItem=items.next();
				
				//判断是否是普通表单元素
				if(fileItem.isFormField()){
					String name=fileItem.getFieldName();
					System.out.println(name+":"+fileItem.getString("utf-8"));
				}else {
					//是文件类型
					String fileNameString=fileItem.getName();
					//获得项目的根路径
					String urlString=this.getServletConfig().getServletContext().getRealPath("/");
					//创建文件对象进行保存操作
					File file=new File(urlString+"images",fileNameString);
					
					//将文件保存到指定文件下
					fileItem.write(file);
					System.out.println("文件上床成功！名称为"+fileItem.getName()+"文件大小"+fileItem.getSize()+"kb");	
					resp.getWriter().print(fileItem.getName());
				}
			}
			
			//for遍历(是否是具有匹配类型文件)
			/*for (FileItem fileItem : list) {
				if (!fileItem.isFormField()) {
					String name = fileItem.getName();
					String end = name.substring(name.lastIndexOf(".") + 1);
					System.out.println("文件名为：" + end);
					if (fileType.contains(end)) {
						File file=new File("D:\\"+fileItem.getName());
						fileItem.write(file);
						System.out.println("上传成功！");
					} else {
						resp.getWriter().print("上传失败！文件类型只能是gif，bmp，jpg");
						System.out.println("上传失败！文件类型只能是gif，bmp，jpg");
					}
				} else {
					System.out.println("其他请求！");
				}
			}*/
			
			
			
		} catch (FileUploadBase.SizeLimitExceededException e) {
			e.printStackTrace();
			resp.getWriter().print("上传失败，文件太大，全部文件的最大限度是" + sfu.getFileSizeMax()
					+ "bytes!");
			System.out.println("上传失败，文件太大，全部文件的最大限度是" + sfu.getFileSizeMax()
					+ "bytes!");
		} catch (FileUploadException e) {
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
