package cn.easybuy.servlet;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jdk.nashorn.internal.ir.RuntimeNode.Request;

import org.apache.ibatis.javassist.compiler.ast.NewExpr;
import org.apache.ibatis.session.SqlSession;

import cn.easybuy.dao.address.AddressMapper;
import cn.easybuy.pojo.Address;
import cn.easybuy.pojo.User;
import cn.easybuy.service.address.AddressServiceImpl;
import cn.easybuy.util.MyBatisUtil;

/**
 * Servlet implementation class IstoselectAddress
 */
@WebServlet("/IstoselectAddress")
public class IstoselectAddress extends AbstractServlet {
	private static final long serialVersionUID = 1L;
	//查询用户所有地址
	public List<Address> toselectAddress(HttpServletRequest req,HttpServletResponse resp) {
		List<Address> address=null;
		System.out.println("userId----------------->"+req.getParameter("userId"));
		address=new AddressServiceImpl().toselectAddress(Integer.parseInt(req.getParameter("userId")));
		System.out.println(address.size());
		return address;
	}
	@Override
	public Class getServletClass() {
		// TODO Auto-generated method stub
		return IstoselectAddress.class;
	}
	//根据用户和地址id修改默认地址
	public int updateAddress(HttpServletRequest req,HttpServletResponse resp) {
		int id=Integer.parseInt(req.getParameter("id"));
		int userId=Integer.parseInt(req.getParameter("userId"));
		AddressServiceImpl asiImpl=new AddressServiceImpl();
		int count=asiImpl.updateAddress(userId, id);
		return count;
	}
	//根据用户id增加地址
	public int addAdress(HttpServletRequest req,HttpServletResponse resp){
		Address address=new Address();
		//获取用户id
		address.setUserId((Integer)((User)(req.getSession().getAttribute("plainUser"))).getId());
		//获取地址
		address.setAddress(req.getParameter("address"));
		//获取时间
		address.setCreateTime(new Date());
		//设置非默认地址
		address.setIsDefault(0);
		AddressServiceImpl asi=new AddressServiceImpl();
		int count=asi.addAdress(address);
		return count;
	}
	
	//根据地址id删除信息
	public int deleteAddress(HttpServletRequest req,HttpServletResponse resp){
		int Aid=Integer.parseInt(req.getParameter("id"));
		AddressServiceImpl del=new AddressServiceImpl();
		int count=del.deleteAddress(Aid);
		return count;
	}
	
}
