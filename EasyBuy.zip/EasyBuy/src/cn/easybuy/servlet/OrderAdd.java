package cn.easybuy.servlet;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;

import cn.easybuy.pojo.Order;
import cn.easybuy.pojo.OrderDetail;
import cn.easybuy.pojo.User;
import cn.easybuy.service.buycar.BuyCarService;
import cn.easybuy.service.buycar.BuyCarServiceImpl;
import cn.easybuy.service.order.OrderServiceImpl;
import cn.easybuy.service.orderdetail.OrderDetailService;
import cn.easybuy.service.orderdetail.OrderDetailServiceImpl;
import cn.easybuy.service.user.UserServiceImpl;

/**
 * Servlet implementation class UserAddOrUpdate
 */
@WebServlet("/orderAdd")
public class OrderAdd extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//接受参数
		String userAddress=req.getParameter("address");
		double cost=Double.parseDouble(req.getParameter("price"));

		
		
		
		System.out.println("userAddress------->"+userAddress);
		System.out.println("cost------->"+cost);
		
		Order order=new Order();
		order.setUserId(((User)req.getSession().getAttribute("plainUser")).getId());
		order.setLoginName(((User)req.getSession().getAttribute("plainUser")).getLoginName());
		order.setCreateTime(new Date());
		order.setUserAddress(userAddress.toString());
		
		//生成订单号
		SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMddHHmmss");
		String newDate=sdf.format(new Date());
		String result="";
		Random random=new Random();
		for(int i=0;i<3;i++){
			result+=random.nextInt(10);
		}
		order.setSerialNumber(newDate+result);
		order.setCost(cost);
		
		
		int count=0;
		//增加订单
		System.out.println("增加");
		count=new OrderServiceImpl().addPhoneOrder(order);
		
		
		
		//查询新增最后订单的订单id
		int orderId=new OrderServiceImpl().selectLastOrderId();
		
		
		
		
		//增加订单详细信息	
		
		//将接受到的json字串转为对象
		String json=req.getParameter("json");
		System.out.println("json为:"+json);
		List<OrderDetail> list=JSON.parseArray(json, OrderDetail.class);
		OrderDetailService orderDetailService=new OrderDetailServiceImpl();
		for (OrderDetail orderDetail : list) {
			orderDetail.setOrderId(orderId);
			System.out.println(orderDetail.getOrderId());
			System.out.println(orderDetail.getCost());
			System.out.println(orderDetail.getProductId());
			System.out.println(orderDetail.getQuantity());
			System.out.println();
			orderDetailService.addOrderDetail(orderDetail);
		}
		
		//删除相关购物车记录
		BuyCarService buyCarService=new BuyCarServiceImpl();
		int cout=buyCarService.deleteBuyCar(order.getUserId());
		
		resp.getWriter().print(order.getSerialNumber());
	}

}