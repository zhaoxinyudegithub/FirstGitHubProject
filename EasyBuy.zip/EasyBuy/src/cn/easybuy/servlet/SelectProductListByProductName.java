package cn.easybuy.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;

import cn.easybuy.pojo.Product;
import cn.easybuy.service.product.ProductService;
import cn.easybuy.service.product.ProductServiceImpl;

/**
 * Servlet implementation class SelectProductNameByProductName
 */
@WebServlet("/selectProductListByProductName")
public class SelectProductListByProductName extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//获取关键字
		String name=req.getParameter("name");
		
		
		ProductService ps=new ProductServiceImpl();
		
		List<Product>list=ps.selectProductListByProductName(name);
		String json=JSON.toJSONString(list);
		System.out.println(json);
		resp.getWriter().print(json);
	}

}
