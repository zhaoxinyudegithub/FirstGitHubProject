package cn.easybuy.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.easybuy.pojo.Category;
import cn.easybuy.pojo.Product;
import cn.easybuy.pojo.User;
import cn.easybuy.service.category.CateGoryServiceImpl;
import cn.easybuy.service.product.ProductServiceImpl;
import cn.easybuy.service.user.UserServiceImpl;

/**
 * Servlet implementation class UserAddOrUpdate
 */
@WebServlet("/categoryAddOrUpdate")
public class CategoryAddOrUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//接受参数
		String name=req.getParameter("name");
		int type=Integer.parseInt(req.getParameter("type"));
		int parentId=Integer.parseInt(req.getParameter("parent"));
		String fileName=req.getParameter("imgFile");
		String img=req.getParameter("img");
		
		int id=0;
		String id1=req.getParameter("id");
		
		System.out.println("id------->"+id);
		System.out.println("fileName------->"+fileName);
		System.out.println("img------->"+img);
		System.out.println("name------->"+name);
		
		Category category=new Category();
		category.setName(name);
		category.setIconClass(img);
		category.setParentId(parentId);
		category.setType(type);
		
		
		
		int count=0;
		//判断是增加还是修改
		if(id1==null){	//增加
			System.out.println("增加");
			count=new CateGoryServiceImpl().addCategory(category);
			System.out.println(count);
			resp.getWriter().print(count);
		}else{			//修改
			id=Integer.parseInt(id1);
			System.out.println("id------->"+id);
			System.out.println("修改");
			category.setId(id);
			count=new CateGoryServiceImpl().updateCategory(category);
			System.out.println(count);
			resp.getWriter().print(count);
		}
		
	}

}