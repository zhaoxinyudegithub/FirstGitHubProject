package cn.easybuy.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.easybuy.pojo.BuyCar;

/**
 * 数据库原数据显示在页面
 * Servlet implementation class newCarServlet
 */
@WebServlet("/newCarServlet")
public class newCarServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//PrintWriter pw=resp.getWriter();
		cn.easybuy.service.buycar.BuyCarService buycar=new cn.easybuy.service.buycar.BuyCarServiceImpl();
		List<BuyCar> list=buycar.selectBuyCarListByUserId(733);
		req.setAttribute("showInfo", list);
		//String js=JSON.toJSONString(list);
		//pw.print(js);
		//pw.close();
		resp.sendRedirect("buyCar1.jsp");
	}

}
