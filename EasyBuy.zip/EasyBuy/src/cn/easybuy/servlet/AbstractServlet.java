package cn.easybuy.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.file.Path;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jdk.nashorn.internal.runtime.ECMAErrors;

import org.eclipse.jdt.internal.compiler.ast.ThisReference;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import sun.invoke.empty.Empty;
import cn.easybuy.util.EmptyUtils;
import cn.easybuy.util.ReturnResult;

/**
 * Servlet implementation class AbstractServlet
 */
@WebServlet("/AbstractServlet")
public abstract class AbstractServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public abstract Class getServletClass();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AbstractServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		//接受处理方法的名称
		String action=req.getParameter("action");
		Method method=null;
		Object result=null;
		//判断参数是否为空
		if(EmptyUtils.isEmpty(action)){
			req.getRequestDispatcher("index.jsp").forward(req, resp);;
		}else {
			try {
				method=getServletClass().getDeclaredMethod(action,HttpServletRequest.class,HttpServletResponse.class);
				result=method.invoke(this, req,resp);
				toView(req, resp, result);
				
			} catch (NoSuchMethodException e) {
				String viewName="404.jsp";
				req.getRequestDispatcher(viewName).forward(req, resp);;
				e.printStackTrace();
			} catch (Exception e) {
				if(result!=null){
					if(result instanceof String){
						String viewName="500.jsp";
						req.getRequestDispatcher(viewName).forward(req, resp);;
					}else {
						ReturnResult returnResult=new ReturnResult();
						returnResult.returnFail("系统错误!");
					}
				}else {
					String viewName="500.jsp";
					req.getRequestDispatcher(viewName).forward(req, resp);;
				}
				e.printStackTrace();
			}
		}
	}
	
	
	//根据返回结果确定执行操作(1.如果是字符串:统一挑战页面     2.如果是对象:变成json字符串)
	public void toView(HttpServletRequest req, HttpServletResponse resp,Object result)throws Exception{
		if(EmptyUtils.isNotEmpty(result)){
			if (result instanceof String) {//进行页面跳转
				write(result, resp);
			}else {
				write(result, resp);
			}
		}
	}
	
	//打印json字符串
	public void write(Object obj,HttpServletResponse resp){
		resp.setContentType("text/html;charset=utf-8");
		String json=JSONObject.toJSONString(obj);
		PrintWriter writer=null;
		if(null!=resp){
			try {
				writer=resp.getWriter();
				writer.print(json);
				System.out.println(json);
				writer.flush();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				writer.close();
			}

		}
	}


}
