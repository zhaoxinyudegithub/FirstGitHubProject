package cn.easybuy.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.easybuy.service.category.CateGoryService;
import cn.easybuy.service.category.CateGoryServiceImpl;
import cn.easybuy.service.product.ProductService;
import cn.easybuy.service.product.ProductServiceImpl;
import cn.easybuy.service.user.UserService;
import cn.easybuy.service.user.UserServiceImpl;

/**
 * Servlet implementation class IsHavePhone
 */
@WebServlet("/isHaveCategoryName")
public class IsHaveCategoryName extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		CateGoryService ps=new CateGoryServiceImpl();
		String name=req.getParameter("name");
		resp.getWriter().print(ps.selectCategoryByName(name));
		System.out.println(ps.selectCategoryByName(name));
	}

}
