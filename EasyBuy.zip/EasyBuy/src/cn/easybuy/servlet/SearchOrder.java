package cn.easybuy.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.easybuy.service.order.OrderService;
import cn.easybuy.service.order.OrderServiceImpl;

import com.alibaba.fastjson.JSON;

/**
 * Servlet implementation class SearchOrder
 */
@WebServlet("/searchOrder")
public class SearchOrder extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//接受参数
		String serialNumber=req.getParameter("serialNumber");
		String loginName=req.getParameter("loginName");
		
		System.out.println("serialNumber--------->"+serialNumber);
		System.out.println("loginName--------->"+loginName);
		
		OrderService os=new OrderServiceImpl();
		System.out.println(JSON.toJSON(os.selectOrderBySerialNumberAndLoginName(serialNumber, loginName)));
		resp.getWriter().print(JSON.toJSON(os.selectOrderBySerialNumberAndLoginName(serialNumber, loginName)));
		
		
		

	}

}
