package cn.easybuy.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.easybuy.service.user.UserService;
import cn.easybuy.service.user.UserServiceImpl;

/**
 * Servlet implementation class IsHavePhone
 */
@WebServlet("/isHaveLoginName")
public class IsHaveLoginName extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		UserService us=new UserServiceImpl();
		resp.getWriter().print(us.selectUserByLoginName(req.getParameter("loginName")));
	}

}
