package cn.easybuy.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;

import cn.easybuy.pojo.News;
import cn.easybuy.service.news.NewsService;
import cn.easybuy.service.news.NewsServiceImpl;

//import com.sun.xml.internal.bind.v2.schemagen.xmlschema.List;

/**
 * 首页展示资讯
 * Servlet implementation class NewsIndex
 */
@WebServlet("/NewsIndex")
public class NewsIndex extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter pw=resp.getWriter();
		NewsService ns=new NewsServiceImpl();
		List<News> list=ns.selectAll();
		String nJ=JSON.toJSONString(list);
		System.out.println(nJ);
		pw.print(nJ);
		pw.close();
	}

}
