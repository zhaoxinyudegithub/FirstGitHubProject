package cn.easybuy.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;

import cn.easybuy.pojo.Product;
import cn.easybuy.service.product.ProductServiceImpl;

/**
 * Servlet implementation class SelectProductListLimit3
 */
@WebServlet("/selectProductListLimit3")
public class SelectProductListLimit3 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		List<Product> list=new ProductServiceImpl().selectProductListLimit3();
		
		String json=JSON.toJSONString(list);
		System.out.println(json);
		resp.getWriter().print(json);
	}

}
