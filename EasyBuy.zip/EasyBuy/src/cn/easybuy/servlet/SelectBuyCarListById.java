package cn.easybuy.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;

import cn.easybuy.pojo.BuyCar;
import cn.easybuy.pojo.Category;
import cn.easybuy.pojo.User;
import cn.easybuy.service.buycar.BuyCarServiceImpl;
import cn.easybuy.service.category.CateGoryServiceImpl;

/**
 * Servlet implementation class SelectCategoryListByParentId
 */
@WebServlet("/selectBuyCarListById")
public class SelectBuyCarListById extends AbstractServlet implements Servlet {
	private static final long serialVersionUID = 1L;



	@Override
	public Class getServletClass() {
		// TODO Auto-generated method stub
		return SelectBuyCarListById.class;
	}
	public List<BuyCar> getShopCart(HttpServletRequest request,HttpServletResponse response) {
		//接受参数
		Integer userId=((User)(request.getSession().getAttribute("plainUser"))).getId();
		
		List<BuyCar>list=new BuyCarServiceImpl().selectBuyCarListByUserId(userId);
				
		return list;
	}
}
