package cn.easybuy.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.easybuy.pojo.User;
import cn.easybuy.service.user.UserServiceImpl;

/**
 * Servlet implementation class UserAddOrUpdate
 */
@WebServlet("/userAdd1")
public class UserAdd extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//接受参数
		String userName=req.getParameter("userName");
		String loginName=req.getParameter("loginName");
		String pwd=req.getParameter("pwd");
		int sex=Integer.parseInt(req.getParameter("sex"));
		String identityCode=req.getParameter("identityCode");
		String email=req.getParameter("email");
		String mobile=req.getParameter("mobile");

		
		
		
		System.out.println("userName------->"+userName);
		System.out.println("loginName------->"+loginName);
		System.out.println("pwd------->"+pwd);
		System.out.println("sex------->"+sex);
		System.out.println("identityCode------->"+identityCode);
		System.out.println("email------->"+email);
		System.out.println("mobile------->"+mobile);
		System.out.println("type------->"+0);
		
		User user=new User();
		user.setUserName(userName);
		user.setLoginName(loginName);
		user.setPassword(pwd);
		user.setSex(sex);
		user.setIdentityCode(identityCode);
		user.setEmail(email);
		user.setMobile(mobile);
		user.setType(0);
		
		int count=0;
			//增加
			System.out.println("增加");
			count=new UserServiceImpl().addUser(user);
			System.out.println(count);
			resp.getWriter().print(count);
		
		
	}

}