package cn.easybuy.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;

import cn.easybuy.pojo.User;
import cn.easybuy.service.category.CateGoryService;
import cn.easybuy.service.category.CateGoryServiceImpl;
import cn.easybuy.service.user.UserService;
import cn.easybuy.service.user.UserServiceImpl;
import cn.easybuy.util.Page;

/**
 * Servlet implementation class UserList
 */
@WebServlet("/sortList")
public class SortList extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	
	@Override
	public void service(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		/*Integer currPageNo=Integer.parseInt(req.getParameter("currPageNo"));
		Integer pageSize=Integer.parseInt(req.getParameter("pageSize"));*/
		CateGoryService cs=new CateGoryServiceImpl();
		int index=1;
		if(req.getParameter("currPageNo")!=null){
			index=Integer.parseInt(req.getParameter("currPageNo"));
		}
		
		Page page=cs.selectCategoryTotalList(index, 15);
		
		
		String json=JSON.toJSONString(page);
		resp.getWriter().print(json);
		System.out.println(json);
	}
    

}
