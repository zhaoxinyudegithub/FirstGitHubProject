package cn.easybuy.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;

import cn.easybuy.pojo.Product;
import cn.easybuy.service.product.ProductServiceImpl;

/**
 * Servlet implementation class SelectProductListByCategory1Limit12
 */
@WebServlet("/selectProductListByCategory1Limit12")
public class SelectProductListByCategory1Limit12 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//接受参数
		Integer category1=Integer.parseInt(req.getParameter("category1"));
		
		List<Product>list=new ProductServiceImpl().selectProductListByCategory1Limit12(category1);
		
		String json=JSON.toJSONString(list);
		System.out.println(json);
		resp.getWriter().print(json);
	}

}
