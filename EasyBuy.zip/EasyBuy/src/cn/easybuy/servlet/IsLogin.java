package cn.easybuy.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;

import cn.easybuy.pojo.User;
import cn.easybuy.service.user.UserService;
import cn.easybuy.service.user.UserServiceImpl;

/**
 * Servlet implementation class IsLogin
 */
@WebServlet("/isLogin")
public class IsLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	public void service(ServletRequest req, ServletResponse resp)
			throws ServletException, IOException {
		//接受值
		String name=req.getParameter("user");
		String pwd=req.getParameter("pwd");
		
		//用户类型
		Integer type=-1;
		UserService us=new UserServiceImpl();
		User user=us.selectUser(name,pwd);
		String json=null;
		if(user!=null){
			json=JSON.toJSONString(user);
			((HttpServletRequest) req).getSession().setAttribute("plainUser",user);
		}
		resp.getWriter().print(json);
		System.out.println(json);
	}
    

}
