package cn.easybuy.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.easybuy.pojo.BuyCar;
import cn.easybuy.pojo.User;
import cn.easybuy.service.buycar.BuyCarServiceImpl;
import cn.easybuy.service.user.UserServiceImpl;

/**
 * Servlet implementation class UserAddOrUpdate
 */
@WebServlet("/buyCarAdd")
public class BuyCarAdd extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//接受参数
		int productId=Integer.parseInt(req.getParameter("productId"));
		int userId=((User)(req.getSession().getAttribute("plainUser"))).getId();
		int number=Integer.parseInt(req.getParameter("number"));
		double sumPrice=Double.parseDouble(req.getParameter("sumPrice"));
		
		
		
		System.out.println("userId------->"+userId);
		System.out.println("productId------->"+productId);
		System.out.println("number------->"+number);
		System.out.println("sumPrice------->"+sumPrice);
		
		BuyCar buyCar=new BuyCar(0, userId, productId, number, sumPrice);
		
		int count=0;
			//增加
			System.out.println("增加");
			count=new BuyCarServiceImpl().addBuyCar(buyCar);
			System.out.println(count);
			resp.getWriter().print(count);
		
		
	}

}