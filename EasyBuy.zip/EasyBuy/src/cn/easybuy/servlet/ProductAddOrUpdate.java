package cn.easybuy.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.easybuy.pojo.Product;
import cn.easybuy.pojo.User;
import cn.easybuy.service.product.ProductServiceImpl;
import cn.easybuy.service.user.UserServiceImpl;

/**
 * Servlet implementation class UserAddOrUpdate
 */
@WebServlet("/productAddOrUpdate")
public class ProductAddOrUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//接受参数
		String name=req.getParameter("name");
		int category1=Integer.parseInt(req.getParameter("category1"));
		int category2=Integer.parseInt(req.getParameter("category2"));
		int category3=Integer.parseInt(req.getParameter("category3"));
		String fileName=req.getParameter("imgFile");
		String img=req.getParameter("img");
		double price=Double.parseDouble(req.getParameter("price"));
		int stock=Integer.parseInt(req.getParameter("stock"));
		String description=req.getParameter("description");
		
		int id=0;
		String id1=req.getParameter("id");
		
		System.out.println("id------->"+id);
		System.out.println("cagegory1------->"+category1);
		System.out.println("cagegory2------->"+category2);
		System.out.println("cagegory3------->"+category3);
		System.out.println("fileName------->"+fileName);
		System.out.println("img------->"+img);
		System.out.println("name------->"+name);
		System.out.println("price------->"+price);
		System.out.println("stock------->"+stock);
		System.out.println("description------->"+description);
		
		Product product=new Product();
		product.setCategoryLevel1Id(category1);
		product.setCategoryLevel2Id(category2);
		product.setCategoryLevel3Id(category3);
		product.setName(name);
		product.setPrice(price);
		product.setStock(stock);
		product.setDescription(description);
		product.setFileName(img);
		
		
		
		int count=0;
		//判断是增加还是修改
		if(id1==null){	//增加
			System.out.println("增加");
			count=new ProductServiceImpl().addProduct(product);
			System.out.println(count);
			resp.getWriter().print(count);
		}else{			//修改
			id=Integer.parseInt(id1);
			System.out.println("修改");
			product.setId(id);
			count=new ProductServiceImpl().updateProduct(product);
			System.out.println(count);
			resp.getWriter().print(count);
		}
		
	}

}