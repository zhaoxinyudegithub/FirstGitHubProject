package cn.easybuy.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.easybuy.service.category.CateGoryService;
import cn.easybuy.service.category.CateGoryServiceImpl;
import cn.easybuy.service.product.ProductService;
import cn.easybuy.service.product.ProductServiceImpl;

/**
 * Servlet implementation class IsHaveProductFileName
 */
@WebServlet("/isHaveProductFileName")
public class IsHaveProductFileName extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String fileName=req.getParameter("fileName");
		
		ProductService ps=new ProductServiceImpl();
		CateGoryService cs=new CateGoryServiceImpl();
		int count=ps.isHaveProductImg(fileName);
		int count2=cs.selectCategoryByIconClass(fileName);
		resp.getWriter().print(count+count2);
		System.out.println("是否存在此商品图片"+(count+count2));
		
	}

}
