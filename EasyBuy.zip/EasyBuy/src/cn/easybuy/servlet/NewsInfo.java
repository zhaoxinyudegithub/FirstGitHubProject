package cn.easybuy.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;

import cn.easybuy.pojo.News;
import cn.easybuy.pojo.User;
import cn.easybuy.service.news.NewsServiceImpl;
import cn.easybuy.service.user.UserServiceImpl;

/**
 * Servlet implementation class UserInfo
 */
@WebServlet("/newsInfo")
public class NewsInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String newsId=req.getParameter("id");
		News news=new NewsServiceImpl().selectNewById(Integer.parseInt(newsId));
		String json=JSON.toJSONString(news);
		resp.getWriter().print(json);
		System.out.println(json);
	}
       
	


}
