package cn.easybuy.dao.user;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.easybuy.pojo.User;

public interface UserMapper {
	//查询所有用户个数
	int getUserListCount();
	
	
	//根据页数查询所有用户列表
	List<User> totalUserList(@Param("pageNum")Integer pageNum,@Param("pageCount")Integer pageCount);
	
	
	
	// 查询用户信息
	User getUserInfo(@Param("user")String user,@Param("pwd")String pwd);
	
	
	//根据id查询用户信息
	User getUserById(@Param("id")Integer id);
	
	
	//根据登录用户名查电话询用户
	int selectUserByLoginName(String loginName);
	
	
	//增加用户信息
	int addUser(User user);
	
	
	
	//修改用户信息
	int updateUser(User user);
	
	
	
	//根据id删除用户信息 
	int deleteUser(Integer id);
}
