package cn.easybuy.dao.order;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.easybuy.pojo.Order;

public interface OrderMapper {
	//查询全部订单信息
	List<Order> selectTotalOrder();
	
	
	//按照订单号和登录用户名查询订单信息
	List<Order> selectOrderBySerialNumberAndLoginName(@Param("serialNumber")String serialNumber,
														@Param("loginName")String loginName);
	
	
	
	//增加订单信息(话费充值)
	int addPhoneOrder(Order order);
	
	
	
	//查询最后增加订单的订单id
	int selectLastOrderId();
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
