package cn.easybuy.dao.buycar;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.easybuy.pojo.BuyCar;
import cn.easybuy.pojo.News;

public interface BuyCarMapper {
	//加入购物车
	int addBuyCar(BuyCar buyCar);
	
	
	//查询对应用户的购物记录
	List<BuyCar>selectBuyCarListByUserId(@Param("userId")Integer id);
	
	//根据用户id清空购物车
	int deleteBuyCar(int id);
	
}
