package cn.easybuy.dao.product;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.easybuy.pojo.Product;

public interface ProductMapper {
	
	//查询所有商品个数
	int getProductListCount();
	
	//查询全部商品信息
	List<Product> selectProductList(@Param("pageNum")Integer pageNum,@Param("count")Integer count);
	
	
	//根据商品id查询商品信息
	Product selectProductById(Integer id);
	
	
	//根据商品名称查询商品名称是否存在
	int selectProductNameIsHave(@Param("name")String name);
	
	
	//增加商品信息
	int addProduct(Product product);
	
	
	//修改商品信息
	int updateProduct(Product product);
	
	
	//删除商品信息
	int deleteProduct(@Param("id")int id);
	
	
	//是否存在某张商品图片
	int isHaveProductImg(@Param("fileName")String fileName);
	
	
	//根据商品名称模糊查询商品名称
	List<String>selectProductNameByProductName(@Param("name")String productName);
	
	
	//根据商品名称模糊查询商品列表
	List<Product>selectProductListByProductName(@Param("name")String productName);
	
	
	
	//查询倒数三条商品
	List<Product>selectProductListLimit3();
	
	
	
	//根据一级分类查询十二条商品信息
	List<Product>selectProductListByCategory1Limit12(@Param("categoryLevel1Id")Integer id);
	
	
	
	
	//根据一级分类查询所有商品信息 
	List<Product>selectProductListByCategory1(@Param("categoryLevel1Id")Integer id);
	
	
	
	
	//根据二级分类查询所有商品信息 
	List<Product>selectProductListByCategory2(@Param("categoryLevel2Id")Integer id);
	
	
	
	
	//根据三级分类查询所有商品信息 
	List<Product>selectProductListByCategory3(@Param("categoryLevel3Id")Integer id);
	
	
	
}
