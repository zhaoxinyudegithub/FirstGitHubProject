package cn.easybuy.dao.address;

import java.util.List;

import cn.easybuy.pojo.Address;

public interface AddressMapper {
	//根据用户id查询
	List<Address> toselectAddress(int userId);
	
	//根据地址id修改默认地址(1)
	int toupdateAddress(int id);
	
	//根据用户id修改默认地址(0)
	int toupdateUser(int userId);
	
	//根据用户id增加地址
	int addAdress(Address address);
	
	//根据地址id删除信息
	int deleteAddress(int id);
}
