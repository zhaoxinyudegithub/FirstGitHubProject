package cn.easybuy.dao.orderdetail;

import cn.easybuy.pojo.OrderDetail;

public interface OrderDetailMapper {
	//增加订单详细信息
	int addOrderDetail(OrderDetail orderDetail);
}
