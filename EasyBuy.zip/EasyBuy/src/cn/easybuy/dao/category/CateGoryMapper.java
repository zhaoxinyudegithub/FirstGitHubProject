package cn.easybuy.dao.category;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.easybuy.pojo.Category;

public interface CateGoryMapper {
	
	//查询分类信息总数
	int selectCategoryCount();
	
	
	//查询所有分类信息
	List<Category> selectCategoryTotalList(@Param("currentPage")Integer currentPage,@Param("pageSize")Integer pageSize);
	
	

	//按等级查询分类信息
	List<Category> selectCategoryByType(@Param("type")Integer type);
	
	
	//根据分类id查询分类信息
	Category selectCategoryById(@Param("id")Integer id);
	
	
	
	//根据分类名称分类名称是否存在
	int selectCategoryByName(@Param("name")String name);
	
	
	
	
	//查询分类图片是否已经存在
	int selectCategoryByIconClass(@Param("iconClass")String iconClass);
	
	
	
	//增加分类信息
	int addCategory(Category category);
	
	
	
	
	//修改分类信息
	int updateCategory(Category category);
	
	
	
	
	//删除选中数组中的分类
	int deleteCategoryByIds(int[]ids);
	
	
	
	
	
	//根据父类分类id查询子类集合
	List<Category>selectCategoryListByParentId(@Param("parentId")Integer parentId);
	
	
	
	
	
	
}
