package cn.easybuy.pojo;

import java.util.Date;
import java.util.List;
/**
 * 订单类
 * @author fitting
 *
 */
public class Order {
	private Integer id;//编号
	private Integer userId;//用户id
	private String loginName;//登录用户名
	private String userAddress;//用户地址
	private Date createTime;//创建时间
	private double cost;//总消费
	private String serialNumber;//订单号
	private List<OrderDetail>orderDetailsList;		//所有订单列表集合
	
	
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getLoginName() {
		return loginName;
	}
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	public String getUserAddress() {
		return userAddress;
	}
	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	
	public List<OrderDetail> getOrderDetailsList() {
		return orderDetailsList;
	}
	public void setOrderDetailsList(List<OrderDetail> orderDetailsList) {
		this.orderDetailsList = orderDetailsList;
	}
	public Order(Integer id, Integer userId, String loginName,
			String userAddress, Date createTime, double cost,
			String serialNumber) {
		super();
		this.id = id;
		this.userId = userId;
		this.loginName = loginName;
		this.userAddress = userAddress;
		this.createTime = createTime;
		this.cost = cost;
		this.serialNumber = serialNumber;
	}
	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}
}
