package cn.easybuy.pojo;
//购物车类
public class BuyCar {
	public BuyCar(int id, int userId, int productId, int number, double sumPrice) {
		super();
		this.id = id;
		this.userId = userId;
		this.productId = productId;
		this.number = number;
		this.sumPrice = sumPrice;
	}
	public BuyCar() {
		super();
		// TODO Auto-generated constructor stub
	}
	private int id;			//购物车id
	private int userId;		//用户id
	private int productId;	//商品id
	private Product product;//商品对象
	private int number;		//商品数量
	private double sumPrice;//总价格
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public double getSumPrice() {
		return sumPrice;
	}
	public void setSumPrice(double sumPrice) {
		this.sumPrice = sumPrice;
	}
	
	
	
}
