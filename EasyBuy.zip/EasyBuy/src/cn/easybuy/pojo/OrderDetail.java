package cn.easybuy.pojo;


/**
 * 订单列表
 * @author fitting
 *
 */
public class OrderDetail {
	private Integer id;//编号
	private Integer orderId;//订单ID
	private Integer productId;//商品ID
	private Product product;	//商品对象
	private Integer quantity;//数量
	private double cost;//金额
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getOrderId() {
		return orderId;
	}
	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
	
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public OrderDetail(Integer id, Integer orderId, Integer productId,
			Integer quantity, double cost) {
		super();
		this.id = id;
		this.orderId = orderId;
		this.productId = productId;
		this.quantity = quantity;
		this.cost = cost;
	}
	public OrderDetail() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
