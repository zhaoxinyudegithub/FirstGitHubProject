package cn.easybuy.service.address;

import java.util.List;

import cn.easybuy.pojo.Address;

public interface AddressService {
		//根据用户id查询
		List<Address> toselectAddress(int userId);
		
		//根据地址id修改默认地址(1)
		int toupdateAddress(int id);
		
		//根据用户id修改默认地址(0)
		int toupdateUser(int userId);
		
		//根据地址和用户id修改默认地址
		int updateAddress(int userId,int id);
		
		//根据用户id增加地址
		int addAdress(Address address);
		
		//根据地址id删除信息
		int deleteAddress(int id);
		
}
