package cn.easybuy.service.address;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;
import org.junit.Test;

import cn.easybuy.dao.address.AddressMapper;
import cn.easybuy.pojo.Address;
import cn.easybuy.test.UserTest;
import cn.easybuy.util.MyBatisUtil;

public class AddressServiceImpl implements AddressService{
	private Logger log=Logger.getLogger(UserTest.class);
	
	//根据用户id查询
	@Override
	public List<Address> toselectAddress(int userId) {
		SqlSession session=null;
		List<Address> address=null;
		try {
			session=MyBatisUtil.getSqlSession();
			address=session.getMapper(AddressMapper.class).toselectAddress(userId);
			for (Address address2 : address) {
				log.debug("用户数据为:"+address2.getAddress());
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return address;
	}

	//根据地址id修改默认地址(1)
	@Override
	public int toupdateAddress(int id) {
		SqlSession session=null;
		int count=0;
		try {
			session=MyBatisUtil.getSqlSession();
			count=session.getMapper(AddressMapper.class).toupdateAddress(id);
			log.debug(count);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return count;
	}

	//根据用户id修改默认地址(0)
	@Override
	public int toupdateUser(int userId) {
		SqlSession session=null;
		int count=0;
		Address address=new Address();
		try {
			session=MyBatisUtil.getSqlSession();
			count=session.getMapper(AddressMapper.class).toupdateUser(userId);
			log.debug(count);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return count;
	}

	//根据地址和用户id修改默认地址
	@Override
	public int updateAddress( int userId,int id) {
		SqlSession session=null;
		int count=0;
		Address address=new Address();
		try {
			session=MyBatisUtil.getSqlSession();
			count=toupdateUser(userId);
			count=toupdateAddress(id);
			log.debug(count);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return count;
	}
	//根据用户id增加地址
	@Override
	public int addAdress(Address address) {
		SqlSession session=null;
		int count=0;
		try {
			session=MyBatisUtil.getSqlSession();
			count=session.getMapper(AddressMapper.class).addAdress(address);
			log.debug(count);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return count;
	}

	@Override
	public int deleteAddress(int id) {
		SqlSession session=null;
		int count=0;
		try {
			session=MyBatisUtil.getSqlSession();
			count=session.getMapper(AddressMapper.class).deleteAddress(id);
			log.debug(count);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return count;
	}
}
