package cn.easybuy.service.user;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;
import org.junit.Test;

import cn.easybuy.util.MyBatisUtil;
import cn.easybuy.util.Page;
import cn.easybuy.dao.user.UserMapper;
import cn.easybuy.pojo.User;

public class UserServiceImpl implements UserService{
	private Logger log=Logger.getLogger(UserServiceImpl.class);
	
	//查询所有用户个数
	@Override
	@Test
	public int getUserListCount() {
		SqlSession session=null;
		int num=0;
		try {
			session=MyBatisUtil.getSqlSession();
			num=session.getMapper(UserMapper.class).getUserListCount();
			log.debug("用户数据为:"+num);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		
		return num;
	}
	
	
	
	//查询对应页数的用户列表
	@Override
	public Page getUserList(Integer pageNum, Integer count) {
		Page page=new Page();
		page.setCurrPageNo(pageNum);
		page.setPageSize(count);
		page.setTotalCount(getUserListCount());
		
		
		SqlSession session=null;
		List<User>list=null;
		try {
			session=MyBatisUtil.getSqlSession();
			list=session.getMapper(UserMapper.class).totalUserList((pageNum-1)*count,count);
			log.debug("用户数据为:"+list.size());
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		
		page.setUserList(list);
		return page;
	}

	
	

	//根据登录用户名和密码查询用户信息
	@Override
	public User selectUser(String name, String pwd) {
		User user=null;
		SqlSession session=null;
		
		try {
			session=MyBatisUtil.getSqlSession();
			user=session.getMapper(UserMapper.class).getUserInfo(name, pwd);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return user;
	}
	
	


	//根据id查询用户
	@Override
	public User getUserById(int id) {
		SqlSession session=null;
		User user=null;
		try {
			session=MyBatisUtil.getSqlSession();
			user=session.getMapper(UserMapper.class).getUserById(id);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return user;
	}



	//根据电话查询用户信息
	@Override
	public int selectUserByLoginName(String loginName) {
		SqlSession session=null;
		int count=0;
		
		try {
			session=MyBatisUtil.getSqlSession();
			count=session.getMapper(UserMapper.class).selectUserByLoginName(loginName);
			log.debug(count);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return count;
	}
	
	
	
	
	//增加用户信息
	@Override
	public int addUser(User user) {
		SqlSession session=null;
		int count=0;
		
		try {
			session=MyBatisUtil.getSqlSession();
			count=session.getMapper(UserMapper.class).addUser(user);
			log.debug(count);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return count;
	}
	
	
	
	
	//增加用户信息
	@Override
	public int updateUser(User user) {
		SqlSession session=null;
		int count=0;
		
		try {
			session=MyBatisUtil.getSqlSession();
			count=session.getMapper(UserMapper.class).updateUser(user);
			log.debug(count);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return count;
	}
	
	
	
	
	
	//根据id删除用户信息
	@Override
	public int deleteUser(Integer id) {
		SqlSession session=null;
		int count=0;
		
		try {
			session=MyBatisUtil.getSqlSession();
			count=session.getMapper(UserMapper.class).deleteUser(id);
			log.debug(count);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return count;
	}
	




	
}
