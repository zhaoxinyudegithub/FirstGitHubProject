package cn.easybuy.service.user;

import java.util.List;

import cn.easybuy.pojo.User;
import cn.easybuy.util.Page;

public interface UserService {
	//查询所有用户个数
	int getUserListCount();
	
	
	//查询对应页数的用户列表
	Page getUserList(Integer pageNum,Integer count);
	
	
	//根据登录用户名和密码查询用户信息
	User selectUser(String name,String pwd);
	
	
	//根据id查询用户
	User getUserById(int id);
	
	
	//根据登录用户名查询用户
	int selectUserByLoginName(String loginName);
	
	
	//增加用户信息
	int addUser(User user);
	
	
	//修改用户信息
	int updateUser(User user);
	
	
	
	//删除用户信息
	int deleteUser(Integer id);
}
