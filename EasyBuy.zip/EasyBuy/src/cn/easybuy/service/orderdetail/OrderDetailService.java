package cn.easybuy.service.orderdetail;

import cn.easybuy.pojo.OrderDetail;

public interface OrderDetailService {
	//增加订单详细信息
	int addOrderDetail(OrderDetail orderDetail);
}
