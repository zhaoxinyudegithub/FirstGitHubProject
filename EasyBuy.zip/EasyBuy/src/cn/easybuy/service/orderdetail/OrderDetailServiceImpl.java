package cn.easybuy.service.orderdetail;

import org.apache.ibatis.session.SqlSession;

import cn.easybuy.dao.orderdetail.OrderDetailMapper;
import cn.easybuy.pojo.OrderDetail;
import cn.easybuy.util.MyBatisUtil;

public class OrderDetailServiceImpl implements OrderDetailService{
	//添加订单详细
	@Override
	public int addOrderDetail(OrderDetail orderDetail) {
		SqlSession session=null;
		int count=0;
		try {
			session=MyBatisUtil.getSqlSession();
			count=session.getMapper(OrderDetailMapper.class).addOrderDetail(orderDetail);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return count;
	}

}
