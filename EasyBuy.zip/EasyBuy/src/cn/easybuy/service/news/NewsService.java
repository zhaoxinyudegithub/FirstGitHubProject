package cn.easybuy.service.news;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.easybuy.pojo.News;
import cn.easybuy.util.Page;

public interface NewsService {
	
	//查询所有资讯
	List<News> selectAll();
	
	
	//查询所有资讯信息总量
	int selectTotalNewsCount();
	
	
	
	//查询所有资讯信息
	Page selectNews(@Param("pageNum")Integer pageNum,@Param("pageSize")Integer pageSize);
	
	
	
	
	//根据id查询资讯信息
	News selectNewById(@Param("id")Integer id);
	
	
	
	
	//增加资讯信息
	int addNews(News news);
	
	
	
	
	//修改资讯信息
	int updateNews(News news);
	
	
	
	
	
	//删除资讯信息
	int deleteNews(@Param("id")Integer id);
	
	
	
}
