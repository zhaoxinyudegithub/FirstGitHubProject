package cn.easybuy.service.news;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import cn.easybuy.dao.news.NewsMapper;
import cn.easybuy.pojo.News;
import cn.easybuy.util.MyBatisUtil;
import cn.easybuy.util.Page;

public class NewsServiceImpl implements NewsService{
	
	//查询所有资讯
	//查询所有资讯信息总量
	@Override
	public List<News> selectAll() {
		SqlSession ss=null;
		List<News> selectAll=new ArrayList<News>();
		
		try {
			ss=MyBatisUtil.getSqlSession();
			selectAll=ss.getMapper(NewsMapper.class).selectNewsAll();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			MyBatisUtil.closeSqlSession(ss);
		}
		return selectAll;
	}
	
	
	

	//查询所有资讯信息总量
	@Override
	public int selectTotalNewsCount() {
		SqlSession session=null;
		int num=0;
		try {
			session=MyBatisUtil.getSqlSession();
			num=session.getMapper(NewsMapper.class).selectTotalNewsCount();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return num;
	}

	
	
	
	
	//查询所有资讯信息
	@Override
	public Page selectNews(Integer pageNum, Integer pageSize) {
		SqlSession session=null;
		Page page=new Page();
		page.setCurrPageNo(pageNum);
		page.setPageSize(pageSize);
		page.setTotalCount(selectTotalNewsCount());
		List<News>list=null;
		try {
			session=MyBatisUtil.getSqlSession();
			list=session.getMapper(NewsMapper.class).selectNews((pageNum-1)*pageSize, pageSize);
			page.setNewList(list);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return page;
	}




	
	//根据id查询资讯信息
	@Override
	public News selectNewById(Integer id) {
		News news=new News();
		SqlSession session=null;
		try {
			session=MyBatisUtil.getSqlSession();
			news=session.getMapper(NewsMapper.class).selectNewById(id);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return news;
	}





	//增加资讯信息
	@Override
	public int addNews(News news) {
		SqlSession session=null;
		int count=0;
		try {
			session=MyBatisUtil.getSqlSession();
			count=session.getMapper(NewsMapper.class).addNews(news);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return count;
	}




	
	//修改资讯信息
	@Override
	public int updateNews(News news) {
		SqlSession session=null;
		int count=0;
		try {
			session=MyBatisUtil.getSqlSession();
			count=session.getMapper(NewsMapper.class).updateNews(news);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return count;
	}





	
	//删除订单信息
	@Override
	public int deleteNews(Integer id) {
		News news=new News();
		SqlSession session=null;
		int count=0;
		try {
			session=MyBatisUtil.getSqlSession();
			count=session.getMapper(NewsMapper.class).deleteNews(id);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return count;
	}






	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
