package cn.easybuy.service.buycar;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.easybuy.pojo.BuyCar;

public interface BuyCarService{
	//加入购物车
	int addBuyCar(BuyCar buyCar);
	
	
	//查询对应用户的购物记录
	List<BuyCar>selectBuyCarListByUserId(@Param("userId")Integer id);
	
	
	//修改购物车商品数量
	public List<BuyCar> newNum(Integer id,Integer num,double price) throws Exception;
	
	
	
	//根据用户id清空购物车
	int deleteBuyCar(int id);
	
	
	
	
	
	
	
}
