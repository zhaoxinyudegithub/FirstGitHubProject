package cn.easybuy.service.buycar;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import cn.easybuy.dao.buycar.BuyCarMapper;
import cn.easybuy.pojo.BuyCar;
import cn.easybuy.util.MyBatisUtil;

public class BuyCarServiceImpl implements BuyCarService{
	//加入购物车
	@Override
	public int addBuyCar(BuyCar buyCar) {
		SqlSession session=null;
		int count=0;
		try {
			session=MyBatisUtil.getSqlSession();
			count=session.getMapper(BuyCarMapper.class).addBuyCar(buyCar);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return count;
	}

	
	
	//查询对应用户的购物记录
	@Override
	public List<BuyCar> selectBuyCarListByUserId(Integer id) {
		SqlSession session=null;
		List<BuyCar>list=null;
		try {
			session=MyBatisUtil.getSqlSession();
			list=session.getMapper(BuyCarMapper.class).selectBuyCarListByUserId(id);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return list;
	}
	
	
	
	//修改数量
	@Override
	public List<BuyCar> newNum(Integer id, Integer num, double price) throws Exception {
		List<BuyCar> list=selectBuyCarListByUserId(id);
		for (BuyCar bc : list) {
			if (bc.getProduct().getId().equals(id)) {
				if (num==0|| num<0) {
					list.remove(this);
					break;
				}else{
					//修改总价
					double sum=0.0;
					sum+=num*price;//前台展示
					bc.setSumPrice(sum);//后台展示
					bc.setNumber(num);//修改数量
				}
				//return list;
			}
		}
		return list;
	}



	//根据用户id清空购物车
	@Override
	public int deleteBuyCar(int id) {
		SqlSession session=null;
		int count=0;
		try {
			session=MyBatisUtil.getSqlSession();
			count=session.getMapper(BuyCarMapper.class).deleteBuyCar(id);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return count;
	}
	
}
