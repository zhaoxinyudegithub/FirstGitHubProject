package cn.easybuy.service.order;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import cn.easybuy.dao.order.OrderMapper;
import cn.easybuy.pojo.Order;
import cn.easybuy.pojo.OrderDetail;
import cn.easybuy.util.MyBatisUtil;

public class OrderServiceImpl implements OrderService{
	
	//查询所有订单信息
	@Override
	public List<Order> selectTotalOrder() {
		SqlSession session=null;
		List<Order> list=null;
		try {
			session=MyBatisUtil.getSqlSession();
			list=session.getMapper(OrderMapper.class).selectTotalOrder();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		if(list==null){
			System.out.println(list);
		}else {
			for (Order order : list) {
				System.out.println("orderId--------------->"+order.getId());
				for (OrderDetail od : order.getOrderDetailsList()) {
					System.out.println(od.getProduct().getName());
				}
			}
			System.out.println();
		}
		return list;
	}

	
	
	
	
	//按照订单号和登录用户名查询订单信息
	@Override
	public List<Order> selectOrderBySerialNumberAndLoginName(
			String serialNumber, String loginName) {
		SqlSession session=null;
		List<Order> list=null;
		try {
			session=MyBatisUtil.getSqlSession();
			list=session.getMapper(OrderMapper.class).selectOrderBySerialNumberAndLoginName(serialNumber, loginName);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		if(list==null){
			System.out.println(list);
		}else {
			for (Order order : list) {
				System.out.println("orderId--------------->"+order.getId());
				for (OrderDetail od : order.getOrderDetailsList()) {
					System.out.println(od.getProduct().getName());
				}
			}
			System.out.println();
		}
		return list;
	}




	//增加订单信息(话费充值)
	@Override
	public int addPhoneOrder(Order order) {
		SqlSession session=null;
		int count=0;
		try {
			session=MyBatisUtil.getSqlSession();
			count=session.getMapper(OrderMapper.class).addPhoneOrder(order);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return count;
	}




	//查询最后增加订单的订单id
	@Override
	public int selectLastOrderId() {
		SqlSession session=null;
		int orderId=0;
		try {
			session=MyBatisUtil.getSqlSession();
			orderId=session.getMapper(OrderMapper.class).selectLastOrderId();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return orderId;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
