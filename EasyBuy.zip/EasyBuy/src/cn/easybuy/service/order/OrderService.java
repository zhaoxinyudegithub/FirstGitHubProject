package cn.easybuy.service.order;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.easybuy.pojo.Order;

public interface OrderService {
	//查询全部订单信息
	List<Order> selectTotalOrder();
	
	//按照订单号和登录用户名查询订单信息
	List<Order> selectOrderBySerialNumberAndLoginName(String serialNumber,String loginName);
	
	
	//增加订单信息(话费充值)
	int addPhoneOrder(Order order);
	
	
	//查询最后增加订单的订单id
	int selectLastOrderId();
	
	
	
	
	
	
	
	
}
