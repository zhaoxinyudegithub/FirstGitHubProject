package cn.easybuy.service.product;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import cn.easybuy.dao.product.ProductMapper;
import cn.easybuy.dao.user.UserMapper;
import cn.easybuy.pojo.Product;
import cn.easybuy.pojo.User;
import cn.easybuy.util.MyBatisUtil;
import cn.easybuy.util.Page;

public class ProductServiceImpl implements ProductService{
	
	//查询所有商品个数
	@Override
	public int getProductListCount() {
		Page page=new Page();
		
		
		SqlSession session=null;
		int num=0;
		try {
			session=MyBatisUtil.getSqlSession();
			num=session.getMapper(ProductMapper.class).getProductListCount();
			System.out.println("商品数量为:"+num);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		
		return num;
	}
	
	
	//查询全部商品信息
	@Override
	public Page selectProductList(Integer pageNum, Integer count) {
		Page page=new Page();
		page.setCurrPageNo(pageNum);
		page.setPageSize(count);
		page.setTotalCount(getProductListCount());
		
		
		SqlSession session=null;
		List<Product>list=null;
		try {
			session=MyBatisUtil.getSqlSession();
			list=session.getMapper(ProductMapper.class).selectProductList((pageNum-1)*count,count);
			System.out.println("用户数据为:"+list.size());
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		
		
		page.setProductList(list);
		
		System.out.println("总页数为：------》"+page.getTotalPageCount());
		System.out.println("当前页数为：------》"+page.getCurrPageNo());
		System.out.println("页数据为：------》"+page.getPageSize());
		for (Product product : page.getProductList()) {
			System.out.println("商品名称-------》"+product.getName());
			System.out.println("商品图片-------》"+product.getFileName());
			System.out.println("库存-------》"+product.getStock());
			System.out.println("价格-------》"+product.getPrice());
			System.out.println("");
		}
		
		return page;
	}


	
	//根据商品id查询商品信息
	@Override
	public Product selectProductById(Integer id) {
		SqlSession session=null;
		Product product=null;
		try {
			session=MyBatisUtil.getSqlSession();
			product=session.getMapper(ProductMapper.class).selectProductById(id);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return product;
	}


	//根据商品名称查询商品信息 是否存在
	@Override
	public int selectProductNameIsHave(String name) {
		SqlSession session=null;
		int num=0;
		try {
			session=MyBatisUtil.getSqlSession();
			num=session.getMapper(ProductMapper.class).selectProductNameIsHave(name);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return num;
	}


	
	
	//增加商品信息
	@Override
	public int addProduct(Product product) {
		SqlSession session=null;
		int num=0;
		try {
			session=MyBatisUtil.getSqlSession();
			num=session.getMapper(ProductMapper.class).addProduct(product);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return num;
	}


	//修改商品信息
	@Override
	public int updateProduct(Product product) {
		SqlSession session=null;
		int num=0;
		try {
			session=MyBatisUtil.getSqlSession();
			num=session.getMapper(ProductMapper.class).updateProduct(product);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return num;
	}
	
	
	
	//删除商品信息
	@Override
	public int deleteProduct(int id) {
		SqlSession session=null;
		int num=0;
		try {
			session=MyBatisUtil.getSqlSession();
			num=session.getMapper(ProductMapper.class).deleteProduct(id);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return num;
	}


	
	//是否存在某张商品图片
	@Override
	public int isHaveProductImg(String fileName) {
		SqlSession session=null;
		int num=0;
		try {
			session=MyBatisUtil.getSqlSession();
			num=session.getMapper(ProductMapper.class).isHaveProductImg(fileName);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return num;
	}


	
	
	
	
	//根据商品名称模糊查询商品名称
	@Override
	public List<String> selectProductNameByProductName(String productName) {
		SqlSession session=null;
		List<String>nameList=null;
		try {
			session=MyBatisUtil.getSqlSession();
			nameList=session.getMapper(ProductMapper.class).selectProductNameByProductName(productName);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return nameList;
	}


	@Override
	public List<Product> selectProductListLimit3() {
		SqlSession session=null;
		int num=0;
		List<Product>list=null;
		try {
			session=MyBatisUtil.getSqlSession();
			list=session.getMapper(ProductMapper.class).selectProductListLimit3();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return list;
	}


	
	
	//根据一级分类查询十二条商品信息
	@Override
	public List<Product> selectProductListByCategory1Limit12(Integer id) {
		SqlSession session=null;
		int num=0;
		List<Product>list=null;
		try {
			session=MyBatisUtil.getSqlSession();
			list=session.getMapper(ProductMapper.class).selectProductListByCategory1Limit12(id);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return list;
	}


	
	
	//根据商品名称模糊查询商品列表
	@Override
	public List<Product> selectProductListByProductName(String productName) {
		SqlSession session=null;
		List<Product>nameList=null;
		try {
			session=MyBatisUtil.getSqlSession();
			nameList=session.getMapper(ProductMapper.class).selectProductListByProductName(productName);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return nameList;
	}


	
	
	
	//根据一级分类查询所有商品信息 
	@Override
	public List<Product> selectProductListByCategory1(Integer id) {
		SqlSession session=null;
		int num=0;
		List<Product>list=null;
		try {
			session=MyBatisUtil.getSqlSession();
			list=session.getMapper(ProductMapper.class).selectProductListByCategory1(id);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return list;
	}


	
	
	
	//根据二级分类查询所有商品信息 
	@Override
	public List<Product> selectProductListByCategory2(Integer id) {
		SqlSession session=null;
		int num=0;
		List<Product>list=null;
		try {
			session=MyBatisUtil.getSqlSession();
			list=session.getMapper(ProductMapper.class).selectProductListByCategory2(id);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return list;
	}


	
	
	
	//根据三级分类查询所有商品信息 
	@Override
	public List<Product> selectProductListByCategory3(Integer id) {
		SqlSession session=null;
		int num=0;
		List<Product>list=null;
		try {
			session=MyBatisUtil.getSqlSession();
			list=session.getMapper(ProductMapper.class).selectProductListByCategory3(id);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return list;
	}





	
	
	
	
}
