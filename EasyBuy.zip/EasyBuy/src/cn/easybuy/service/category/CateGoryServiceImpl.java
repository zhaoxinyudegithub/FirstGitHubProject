package cn.easybuy.service.category;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.SqlSession;

import cn.easybuy.dao.category.CateGoryMapper;
import cn.easybuy.pojo.Category;
import cn.easybuy.util.MyBatisUtil;
import cn.easybuy.util.Page;

public class CateGoryServiceImpl implements CateGoryService{
	
	

	//查询分类信息总数
	@Override
	public int selectCategoryCount() {
		SqlSession session=null;
		int count=0;
		try {
			session=MyBatisUtil.getSqlSession();
			count=session.getMapper(CateGoryMapper.class).selectCategoryCount();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return count;
	}
	
	
	
	
	//查询所有分类信息
	@Override
	public Page selectCategoryTotalList(Integer currentPage,Integer pageSize) {
		SqlSession session=null;
		List<Category>list=null;
		Page page=new Page();
		page.setCurrPageNo(currentPage);
		page.setPageSize(pageSize);
		page.setTotalCount(selectCategoryCount());
		try {
			session=MyBatisUtil.getSqlSession();
			list=session.getMapper(CateGoryMapper.class).selectCategoryTotalList((currentPage-1)*pageSize,pageSize);
			page.setCategoryList(list);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return page;
	}
	
	
	
	
	
	
	//按等级查询分类信息
	@Override
	public List<Category> selectCategoryByType(Integer type) {
		SqlSession session=null;
		List<Category>list=null;
		try {
			session=MyBatisUtil.getSqlSession();
			list=session.getMapper(CateGoryMapper.class).selectCategoryByType(type);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return list;
	}




	
	//根据分类id查询分类信息
	@Override
	public Category selectCategoryById(Integer id) {
		SqlSession session=null;
		Category category=null;
		try {
			session=MyBatisUtil.getSqlSession();
			category=session.getMapper(CateGoryMapper.class).selectCategoryById(id);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return category;
	}




	
	
	//根据分类名称分类名称是否存在
	@Override
	public int selectCategoryByName(String name) {
		SqlSession session=null;
		int count=0;
		try {
			session=MyBatisUtil.getSqlSession();
			count=session.getMapper(CateGoryMapper.class).selectCategoryByName(name);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return count;
	}




	
	//查询分类图片是否已经存在
	@Override
	public int selectCategoryByIconClass(String iconClass) {
		SqlSession session=null;
		int count=0;
		try {
			session=MyBatisUtil.getSqlSession();
			count=session.getMapper(CateGoryMapper.class).selectCategoryByIconClass(iconClass);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return count;
	}




	
	//增加分类信息
	@Override
	public int addCategory(Category category) {
		SqlSession session=null;
		int count=0;
		try {
			session=MyBatisUtil.getSqlSession();
			count=session.getMapper(CateGoryMapper.class).addCategory(category);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return count;
	}




	//修改分类信息
	@Override
	public int updateCategory(Category category) {
		SqlSession session=null;
		int count=0;
		try {
			session=MyBatisUtil.getSqlSession();
			count=session.getMapper(CateGoryMapper.class).updateCategory(category);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return count;
	}




	
	//删除选中数组中的分类
	@Override
	public int deleteCategoryByIds(int[] ids) {
		SqlSession session=null;
		int count=0;
		try {
			session=MyBatisUtil.getSqlSession();
			count=session.getMapper(CateGoryMapper.class).deleteCategoryByIds(ids);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return count;
	}




	//根据父类分类id查询子类集合
	@Override
	public List<Category> selectCategoryListByParentId(Integer parentId) {
		SqlSession session=null;
		List<Category>list=null;
		try {
			session=MyBatisUtil.getSqlSession();
			list=session.getMapper(CateGoryMapper.class).selectCategoryListByParentId(parentId);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		return list;
	}




	
	//根据父父类分类id查询子类集合
	@Override
	public List<Category> selectCategoryListByParentPrentId(Integer parentId) {
		SqlSession session=null;
		List<Category>list1=null;
		List<Category>list=new ArrayList<Category>();
		try {
			session=MyBatisUtil.getSqlSession();
			list1=session.getMapper(CateGoryMapper.class).selectCategoryListByParentId(parentId);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session!=null){
				session.close();
			}
		}
		for (Category category : list1) {
			System.out.println("直系儿子有:"+category.getName());
			List<Category>list2=selectCategoryListByParentId(category.getId());
			for (Category category2 : list2) {
				System.out.println("远亲孙子有:"+category2.getName());
				list.add(category2);
			}
		}
		return list;
	}





	

	
	
	

	
	
	
	
	
	
	
}
